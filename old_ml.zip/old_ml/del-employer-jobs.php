<?php
include 'admin/assets/_dbconnect.php';
if(isset($_GET['type'])=='delete'){
    $id=$_GET['id'];
    mysqli_query($con,"DELETE FROM job_post WHERE id='$id'");
    header('location:employer-manage-jobs.php');

}

?>