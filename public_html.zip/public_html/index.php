<?php

$request = $_SERVER['REQUEST_URI'];
$router = str_replace('job_portal/', '', $request);


$id = '';
if (isset($arr[2])) {
      $id = $arr[2];
}

// 1
if ($router == '/' || $router == '/home') {
      include('home.php');
}

// 2
else if ($router == '/signup') {
      include('signup.php');
}

//3
else if ($router == '/signin') {
      include('signin.php');
}

// 4
elseif ($router == '/signout') {
      include($router == 'signout.php');
}

// 5
else if ($router == '/about-us') {
      include('about-us.php');
}

// 6
else if ($router == '/candidate-dashboard-changed-password') {
      include('candidate-dashboard-changed-password.php');
}

// 7
else if ($router == '/candidate-detail') {
      include('candidate-detail.php');
}

// 8
elseif ($router == '/mobile_otp') {
      include($router == 'mobile_otp.php');
}

// 9
elseif ($router == '/faq') {
      include($router == 'faq.php');
}

// 10
elseif ($router == '/employer-detail') {
      include($router == 'employer-detail.php');
}

// 11
elseif ($router == '/employer-detail-three') {
      include($router == 'employer-detail-three.php');
}

// 12
elseif ($router == '/employer-dashboard') {
      include($router == 'employer-dashboard.php');
}

// 13
else if ($router == '/employer-dashboard-profile-seting') {
      include('employer-dashboard-profile-seting.php');
}

// 14
else if ($router == '/employer-dashboard-confirmation') {
      include('employer-dashboard-confirmation.php');
}

// 15
else if ($router == '/employer-dashboard-changed-password') {
      include('employer-dashboard-changed-password.php');
}

// 16
else if ($router == '/email_verification') {
      include('email_verification.php');
}

//17
else if ($router == '/contact-us') {
      include('contact-us.php');
}

//18
elseif ($router == '/skill' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'skill.php');
}

//19
elseif ($router == '/experience' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'experience.php');
}

//20
elseif ($router == '/employer-manage-jobs.php' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'employer-manage-jobs.php');
}

//21
elseif ($router == '/shortlist_manage' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'shortlist_manage.php');
}

//22
elseif ($router == '/resume5' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'resume5.php');
}

//23
elseif ($router == '/project' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'project.php');
}

//24
elseif ($router == '/employer-dashboard-transactions' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'employer-dashboard-transactions.php');
}

//25
else if ($router == '/employer-dashboard-resumes' || preg_match("/service\/[0-9]/i", $router)) {
      include('employer-dashboard-resumes.php');
}

//26
elseif ($router == '/portfolio' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'portfolio.php');
}

//27
else if ($router == '/employer-dashboard-pkgpayment' || preg_match("/service\/[0-9]/i", $router)) {
      include('employer-dashboard-pkgpayment.php');
}

//28
else if ($router == '/employer-dashboard-packages' || preg_match("/service\/[0-9]/i", $router)) {
      include('employer-dashboard-packages.php');
}

//29
else if ($router == '/employer-dashboard-newjob' || preg_match("/service\/[0-9]/i", $router)) {
      include('employer-dashboard-newjob.php');
}

//30
else if ($router == '/employer-dashboard-manage-jobs' || preg_match("/service\/[0-9]/i", $router)) {
      include('employer-dashboard-manage-jobs.php');
}

//31
elseif ($router == '/training-and-course' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'training-and-course.php');
}

//32
elseif ($router == '/job-packages' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'job-packages.php');
}

//33
else if ($router == '/employer-dashboard-applied-candidate' || preg_match("/service\/[0-9]/i", $router)) {
      include('employer-dashboard-applied-candidate.php');
}

//34
elseif ($router == '/job-detail-two' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'job-detail-two.php');
}

//35
else if ($router == '/education' || preg_match("/service\/[0-9]/i", $router)) {
      include('education.php');
}

//36
else if ($router == '/del_saved_jobs' || preg_match("/service\/[0-9]/i", $router)) {
      include('del_saved_jobs.php');
}

//37
elseif ($router == '/internship' || preg_match("/service\/[0-9]/i", $router)) {
      include($router == 'internship.php');
}

//38
else if ($router == '/candidate-gen-resume' || preg_match("/service\/[0-9]/i", $router)) {
      include('candidate-gen-resume.php');
}

//39
else if ($router == '/candidate-listings' || preg_match("/service\/[0-9]/i", $router)) {
      include('candidate-listings.php');
}

//40
else if ($router == '/candidate-dashboard-saved-jobs' || preg_match("/service\/[0-9]/i", $router)) {
      include('candidate-dashboard-saved-jobs.php');
}

//41
else if ($router == '/candidate-dashboard-resume' || preg_match("/service\/[0-9]/i", $router)) {
      include('candidate-dashboard-resume.php');
}

//42
else if ($router == '/candidate-dashboard-profile-seting' || preg_match("/service\/[0-9]/i", $router)) {
      include('candidate-dashboard-profile-seting.php');
}

//43
else if ($router == '/candidate-dashboard-job-alert' || preg_match("/service\/[0-9]/i", $router)) {
      include('candidate-dashboard-job-alert.php');
}

//44
else if ($router == '/candidate-dashboard-cv-manager' || preg_match("/service\/[0-9]/i", $router)) {
      include('candidate-dashboard-cv-manager.php');
}

//45
else if ($router == '/employer-list' || preg_match("/service\/[0-9]/i", $router)) {
      include('employer-list.php');
}

//46
else if ($router == '/candidate-dashboard-applied-jobs' || preg_match("/service\/[0-9]/i", $router)) {
      include('candidate-dashboard-applied-jobs.php');
}

//47
else if ($router == '/job-listings' || preg_match("/service\/[0-9]/i", $router)) {
      include('job-listings.php');
}