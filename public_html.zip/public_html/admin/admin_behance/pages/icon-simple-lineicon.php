<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Concept - Bootstrap 4 Admin Dashboard Template</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="../assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/libs/css/style.css">
    <link rel="stylesheet" href="../assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="../assets/vendor/fonts/simple-line-icons/css/simple-line-icons.css">
</head>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="../index.php">Concept</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <li class="nav-item">
                            <div id="custom-search" class="top-search-bar">
                                <input class="form-control" type="text" placeholder="Search..">
                            </div>
                        </li>
                        <li class="nav-item dropdown notification">
                            <a class="nav-link nav-icons" href="#" id="navbarDropdownMenuLink1" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false"><i class="fas fa-fw fa-bell"></i> <span
                                    class="indicator"></span></a>
                            <ul class="dropdown-menu dropdown-menu-right notification-dropdown">
                                <li>
                                    <div class="notification-title"> Notification</div>
                                    <div class="notification-list">
                                        <div class="list-group">
                                            <a href="#" class="list-group-item list-group-item-action active">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-2.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Jeremy
                                                            Rakestraw</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-3.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">John Abraham</span>is
                                                        now following you
                                                        <div class="notification-date">2 days ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-4.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Monaan Pechi</span> is
                                                        watching your main repository
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-5.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Jessica
                                                            Caruso</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="list-footer"> <a href="#">View all notifications</a></div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown connection">
                            <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false"> <i class="fas fa-fw fa-th"></i> </a>
                            <ul class="dropdown-menu dropdown-menu-right connection-dropdown">
                                <li class="connection-list">
                                    <div class="row">
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/github.png"
                                                    alt=""> <span>Github</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/dribbble.png"
                                                    alt=""> <span>Dribbble</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/dropbox.png"
                                                    alt=""> <span>Dropbox</span></a>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img
                                                    src="../assets/images/bitbucket.png" alt="">
                                                <span>Bitbucket</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img
                                                    src="../assets/images/mail_chimp.png" alt=""><span>Mail
                                                    chimp</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/slack.png"
                                                    alt=""> <span>Slack</span></a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="conntection-footer"><a href="#">More</a></div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img
                                    src="../assets/images/avatar-1.jpg" alt=""
                                    class="user-avatar-md rounded-circle"></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown"
                                aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info">
                                    <h5 class="mb-0 text-white nav-user-name">John Abraham</h5>
                                    <span class="status"></span><span class="ml-2">Available</span>
                                </div>
                                <a class="dropdown-item" href="#"><i class="fas fa-user mr-2"></i>Account</a>
                                <a class="dropdown-item" href="#"><i class="fas fa-cog mr-2"></i>Setting</a>
                                <a class="dropdown-item" href="#"><i class="fas fa-power-off mr-2"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link active" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-1" aria-controls="submenu-1"><i
                                        class="fa fa-fw fa-user-circle"></i>Dashboard <span
                                        class="badge badge-success">6</span></a>
                                <div id="submenu-1" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="index.php" data-toggle="collapse"
                                                aria-expanded="false" data-target="#submenu-1-2"
                                                aria-controls="submenu-1-2">E-Commerce</a>
                                            <div id="submenu-1-2" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../index.php">E Commerce Dashboard</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../ecommerce-product.php">Product
                                                            List</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../ecommerce-product-single.php">Product Single</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../ecommerce-product-checkout.php">Product
                                                            Checkout</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="../dashboard-finance.php">Finance</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="../dashboard-sales.php">Sales</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                                data-target="#submenu-1-1" aria-controls="submenu-1-1">Infulencer</a>
                                            <div id="submenu-1-1" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../dashboard-influencer.php">Influencer</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../influencer-finder.php">Influencer
                                                            Finder</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../influencer-profile.php">Influencer
                                                            Profile</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-2" aria-controls="submenu-2"><i
                                        class="fa fa-fw fa-rocket"></i>UI Elements</a>
                                <div id="submenu-2" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="cards.php">Cards <span
                                                    class="badge badge-secondary">New</span></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="general.php">General</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="carousel.php">Carousel</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="listgroup.php">List Group</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="typography.php">Typography</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="accordions.php">Accordions</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="tabs.php">Tabs</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-3" aria-controls="submenu-3"><i
                                        class="fas fa-fw fa-chart-pie"></i>Chart</a>
                                <div id="submenu-3" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-c3.php">C3 Charts</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-chartist.php">Chartist Charts</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-charts.php">Chart</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-morris.php">Morris</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-sparkline.php">Sparkline</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-gauge.php">Guage</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-4" aria-controls="submenu-4"><i
                                        class="fab fa-fw fa-wpforms"></i>Forms</a>
                                <div id="submenu-4" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="form-elements.php">Form Elements</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="form-validation.php">Parsely Validations</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="multiselect.php">Multiselect</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-5" aria-controls="submenu-5"><i
                                        class="fas fa-fw fa-table"></i>Tables</a>
                                <div id="submenu-5" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="general-table.php">General Tables</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="data-tables.php">Data Tables</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-divider">
                                Features
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-6" aria-controls="submenu-6"><i
                                        class="fas fa-fw fa-file"></i>Pages</a>
                                <div id="submenu-6" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="invoice.php">Invoice</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="blank-page.php">Blank Page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="blank-page-header.php">Blank Page Header</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="login.php">Login</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="404-page.php">404 page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="sign-up.php">Sign up Page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="forgot-password.php">Forgot Password</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="pricing.php">Pricing Tables</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="timeline.php">Timeline</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="calendar.php">Calendar</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="sortable-nestable-lists.php">Sortable/Nestable
                                                List</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="widgets.php">Widgets</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="media-object.php">Media Objects</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="cropper-image.php">Cropper</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="color-picker.php">Color Picker</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-7" aria-controls="submenu-7"><i
                                        class="fas fa-fw fa-inbox"></i>Apps <span
                                        class="badge badge-secondary">New</span></a>
                                <div id="submenu-7" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="inbox.php">Inbox</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="email-details.php">Email Detail</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="email-compose.php">Email Compose</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="message-chat.php">Message Chat</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-8" aria-controls="submenu-8"><i
                                        class="fas fa-fw fa-columns"></i>Icons</a>
                                <div id="submenu-8" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-fontawesome.php">FontAwesome Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-material.php">Material Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-simple-lineicon.php">Simpleline Icon</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-themify.php">Themify Icon</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-flag.php">Flag Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-weather.php">Weather Icon</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-9" aria-controls="submenu-9"><i
                                        class="fas fa-fw fa-map-marker-alt"></i>Maps</a>
                                <div id="submenu-9" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="map-google.php">Google Maps</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="map-vector.php">Vector Maps</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-10" aria-controls="submenu-10"><i
                                        class="fas fa-f fa-folder"></i>Menu Level</a>
                                <div id="submenu-10" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="#">Level 1</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                                data-target="#submenu-11" aria-controls="submenu-11">Level 2</a>
                                            <div id="submenu-11" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="#">Level 1</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="#">Level 2</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#">Level 3</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
            <div class="container-fluid dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Simpleline Icons </h2>
                            <p class="pageheader-text">Proin placerat ante duiullam scelerisque a velit ac porta, fusce
                                sit amet vestibulum mi. Morbi lobortis pulvinar quam.</p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Icons</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Simpleline Icons</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->

                <div class="row">
                    <!-- ============================================================== -->
                    <!-- simple lineicon icons  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Control Icons</h4>
                                <h6 class="card-subtitle">use class <code>icon-</code> icon name in i tag</h6>
                            </div>
                            <div class="card-body">
                                <div class="icon-list-demo row">
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-user"></i> icon-user
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-people"></i> icon-people
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-user-female"></i> icon-user-female
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-user-follow"></i> icon-user-follow
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-user-following"></i> icon-user-following
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-user-unfollow"></i> icon-user-unfollow
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-login"></i> icon-login
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-logout"></i> icon-logout
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-emotsmile"></i> icon-emotsmile
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-phone"></i> icon-phone
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-call-end"></i> icon-call-end
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-call-in"></i> icon-call-in
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-call-out"></i> icon-call-out
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-map"></i> icon-map
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-location-pin"></i> icon-location-pin
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-direction"></i> icon-direction
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-directions"></i> icon-directions
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-compass"></i> icon-compass
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-layers"></i> icon-layers
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-menu"></i> icon-menu
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-list"></i> icon-list
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-options-vertical"></i> icon-options-vertical
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-options"></i> icon-options
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-arrow-down"></i> icon-arrow-down
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-arrow-left"></i> icon-arrow-left
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-arrow-right"></i> icon-arrow-right
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-arrow-up"></i> icon-arrow-up
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-arrow-up-circle"></i> icon-arrow-up-circle
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-arrow-left-circle"></i> icon-arrow-left-circle
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-arrow-right-circle"></i> icon-arrow-right-circle
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-arrow-down-circle"></i> icon-arrow-down-circle
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-check"></i> icon-check
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-clock"></i> icon-clock
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-plus"></i> icon-plus
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-close"></i> icon-close
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-trophy"></i> icon-trophy
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-screen-smartphone"></i> icon-screen-smartphone
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-screen-desktop"></i> icon-screen-desktop
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-plane"></i> icon-plane
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-notebook"></i> icon-notebook
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-mustache"></i> icon-mustache
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-mouse"></i> icon-mouse
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-magnet"></i> icon-magnet
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-energy"></i> icon-energy
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-disc"></i> icon-disc
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-cursor"></i> icon-cursor
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-cursor-move"></i> icon-cursor-move
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-crop"></i> icon-crop
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-chemistry"></i> icon-chemistry
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-speedometer"></i> icon-speedometer
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-shield"></i> icon-shield
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-screen-tablet"></i> icon-screen-tablet
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-magic-wand"></i> icon-magic-wand
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-hourglass"></i> icon-hourglass
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-graduation"></i> icon-graduation
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-ghost"></i> icon-ghost
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-game-controller"></i> icon-game-controller
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-fire"></i> icon-fire
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-eyeglass"></i> icon-eyeglass
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-envelodashboard-open"></i> icon-envelodashboard-open
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-envolodashboard-letter"></i> icon-envolodashboard-letter
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-bell"></i> icon-bell
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-badge"></i> icon-badge
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-anchor"></i> icon-anchor
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-wallet"></i> icon-wallet
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-vector"></i> icon-vector
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-speech"></i> icon-speech
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-puzzle"></i> icon-puzzle
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-printer"></i> icon-printer
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-present"></i> icon-present
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-playlist"></i> icon-playlist
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-pin"></i> icon-pin
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-picture"></i> icon-picture
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-handbag"></i> icon-handbag
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-globe-alt"></i> icon-globe-alt
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-globe"></i> icon-globe
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-folder-alt"></i> icon-folder-alt
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-folder"></i> icon-folder
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-film"></i> icon-film
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-feed"></i> icon-feed
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-drop"></i> icon-drop
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-drawar"></i> icon-drawar
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-docs"></i> icon-docs
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-doc"></i> icon-doc
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-diamond"></i> icon-diamond
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-cup"></i> icon-cup
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-calculator"></i> icon-calculator
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-bubbles"></i> icon-bubbles
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-briefcase"></i> icon-briefcase
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-book-open"></i> icon-book-open
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-basket-loaded"></i> icon-basket-loaded
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-basket"></i> icon-basket
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-bag"></i> icon-bag
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-action-undo"></i> icon-action-undo
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-action-redo"></i> icon-action-redo
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-wrench"></i> icon-wrench
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-umbrella"></i> icon-umbrella
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-trash"></i> icon-trash
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-tag"></i> icon-tag
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-support"></i> .icon-support
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-frame"></i> icon-frame
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-size-fullscreen"></i> icon-size-fullscreen
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-size-actual"></i> icon-size-actual
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-shuffle"></i> icon-shuffle
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-share-alt"></i> icon-share-alt
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-share"></i> icon-share
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-rocket"></i> icon-rocket
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-question"></i> icon-question
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-pie-chart"></i> icon-pie-chart
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-pencil"></i> icon-pencil
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-note"></i> icon-note
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-loop"></i> icon-loop
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-home"></i> icon-home
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-grid"></i> icon-grid
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-graph"></i> icon-graph
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-microphone"></i> icon-microphone
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-music-tone-alt"></i> icon-music-tone-alt
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-music-tone"></i> icon-music-tone
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-earphones-alt"></i> icon-earphones-alt
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-earphones"></i> icon-earphones
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-equalizer"></i> icon-equalizer
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-like"></i> icon-like
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-dislike"></i> icon-dislike
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-control-start"></i> icon-control-start
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-control-rewind"></i> icon-control-rewind
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-control-play"></i> icon-control-play
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-control-pause"></i> icon-control-pause
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-control-forward"></i> icon-control-forward
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-control-end"></i> icon-control-end
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-volume-1"></i> icon-volume-1
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-volume-2"></i> icon-volume-2
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-volume-off"></i> icon-volume-off
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-calendar"></i> icon-calendar
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-bulb"></i> icon-bulb
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-chart"></i> icon-chart
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-ban"></i> icon-ban
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-bubble"></i> icon-bubble
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-camrecorder"></i> icon-camrecorder
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-camera"></i> icon-camera
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-cloud-download"></i> icon-cloud-download
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-cloud-upload"></i> icon-cloud-upload
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-eye"></i> icon-eye
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-flag"></i> icon-flag
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-heart"></i> icon-heart
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-info"></i> icon-info
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-key"></i> icon-key
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-link"></i> icon-link
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-lock"></i> icon-lock
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-lock-open"></i> icon-lock-open
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-magnifier"></i> icon-magnifier
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-magnifier-add"></i> icon-magnifier-add
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-magnifier-remove"></i> icon-magnifier-remove
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-paper-clip"></i> icon-paper-clip
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-paper-plane"></i> icon-paper-plane
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-power"></i> icon-power
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-refresh"></i> icon-refresh
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-reload"></i> icon-reload
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-settings"></i> icon-settings
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-star"></i> icon-star
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-symble-female"></i> icon-symble-female
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-symbol-male"></i> icon-symbol-male
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-target"></i> icon-target
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-credit-card"></i> icon-credit-card
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-paypal"></i> icon-paypal
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-tumblr"></i> icon-social-tumblr
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-twitter"></i> icon-social-twitter
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-facebook"></i> icon-social-facebook
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-instagram"></i> icon-social-instagram
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-linkedin"></i> icon-social-linkedin
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-pintarest"></i> icon-social-pintarest
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-github"></i> icon-social-github
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-gplus"></i> icon-social-gplus
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-reddit"></i> icon-social-reddit
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-skype"></i> icon-social-skype
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-dribbble"></i> icon-social-dribbble
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-behance"></i> icon-social-behance
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-foursqare"></i> icon-social-foursqare
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-soundcloud"></i> icon-social-soundcloud
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-spotify"></i> icon-social-spotify
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-stumbleupon"></i> icon-social-stumbleupon
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-youtube"></i> icon-social-youtube
                                    </div>
                                    <div class="col-sm-6 col-md-4 col-lg-3 sl-icon">
                                        <i class="icon-social-dropbox"></i> icon-social-dropbox
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end simple lineicon icons  -->
                    <!-- ============================================================== -->
                </div>

            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <div class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            Copyright © 2018 Concept. All rights reserved. Dashboard by <a
                                href="https://colorlib.com/wp/">Colorlib</a>.
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            <div class="text-md-right footer-links d-none d-sm-block">
                                <a href="javascript: void(0);">About</a>
                                <a href="javascript: void(0);">Support</a>
                                <a href="javascript: void(0);">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="../assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <script src="../assets/libs/js/main-js.js"></script>
</body>

</html>