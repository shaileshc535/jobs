<?php
include('includes/_header.php');
?>

<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content ">
            <h1>Import Section</h1>
        </div>

        <?php
        include('includes/_footer.php');
        ?>