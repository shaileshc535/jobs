<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Concept - Bootstrap 4 Admin Dashboard Template</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="../assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/libs/css/style.css">
    <link rel="stylesheet" href="../assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="../assets/vendor/fonts/themify-icons/themify-icons.css">
</head>

<body>
    <div class="dashboard-main-wrapper">
        <!-- ============================================================== -->
        <!-- main wrapper -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="../index.php">Concept</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <li class="nav-item">
                            <div id="custom-search" class="top-search-bar">
                                <input class="form-control" type="text" placeholder="Search..">
                            </div>
                        </li>
                        <li class="nav-item dropdown notification">
                            <a class="nav-link nav-icons" href="#" id="navbarDropdownMenuLink1" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false"><i class="fas fa-fw fa-bell"></i> <span
                                    class="indicator"></span></a>
                            <ul class="dropdown-menu dropdown-menu-right notification-dropdown">
                                <li>
                                    <div class="notification-title"> Notification</div>
                                    <div class="notification-list">
                                        <div class="list-group">
                                            <a href="#" class="list-group-item list-group-item-action active">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-2.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Jeremy
                                                            Rakestraw</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-3.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">John Abraham</span>is
                                                        now following you
                                                        <div class="notification-date">2 days ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-4.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Monaan Pechi</span> is
                                                        watching your main repository
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-5.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Jessica
                                                            Caruso</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="list-footer"> <a href="#">View all notifications</a></div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown connection">
                            <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false"> <i class="fas fa-fw fa-th"></i> </a>
                            <ul class="dropdown-menu dropdown-menu-right connection-dropdown">
                                <li class="connection-list">
                                    <div class="row">
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/github.png"
                                                    alt=""> <span>Github</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/dribbble.png"
                                                    alt=""> <span>Dribbble</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/dropbox.png"
                                                    alt=""> <span>Dropbox</span></a>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img
                                                    src="../assets/images/bitbucket.png" alt="">
                                                <span>Bitbucket</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img
                                                    src="../assets/images/mail_chimp.png" alt=""><span>Mail
                                                    chimp</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/slack.png"
                                                    alt=""> <span>Slack</span></a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="conntection-footer"><a href="#">More</a></div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img
                                    src="../assets/images/avatar-1.jpg" alt=""
                                    class="user-avatar-md rounded-circle"></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown"
                                aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info">
                                    <h5 class="mb-0 text-white nav-user-name">John Abraham</h5>
                                    <span class="status"></span><span class="ml-2">Available</span>
                                </div>
                                <a class="dropdown-item" href="#"><i class="fas fa-user mr-2"></i>Account</a>
                                <a class="dropdown-item" href="#"><i class="fas fa-cog mr-2"></i>Setting</a>
                                <a class="dropdown-item" href="#"><i class="fas fa-power-off mr-2"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link active" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-1" aria-controls="submenu-1"><i
                                        class="fa fa-fw fa-user-circle"></i>Dashboard <span
                                        class="badge badge-success">6</span></a>
                                <div id="submenu-1" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="index.php" data-toggle="collapse"
                                                aria-expanded="false" data-target="#submenu-1-2"
                                                aria-controls="submenu-1-2">E-Commerce</a>
                                            <div id="submenu-1-2" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../index.php">E Commerce Dashboard</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../ecommerce-product.php">Product
                                                            List</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../ecommerce-product-single.php">Product Single</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../ecommerce-product-checkout.php">Product
                                                            Checkout</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="../dashboard-finance.php">Finance</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="../dashboard-sales.php">Sales</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                                data-target="#submenu-1-1" aria-controls="submenu-1-1">Infulencer</a>
                                            <div id="submenu-1-1" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../dashboard-influencer.php">Influencer</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../influencer-finder.php">Influencer
                                                            Finder</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../influencer-profile.php">Influencer
                                                            Profile</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-2" aria-controls="submenu-2"><i
                                        class="fa fa-fw fa-rocket"></i>UI Elements</a>
                                <div id="submenu-2" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="cards.php">Cards <span
                                                    class="badge badge-secondary">New</span></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="general.php">General</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="carousel.php">Carousel</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="listgroup.php">List Group</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="typography.php">Typography</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="accordions.php">Accordions</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="tabs.php">Tabs</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-3" aria-controls="submenu-3"><i
                                        class="fas fa-fw fa-chart-pie"></i>Chart</a>
                                <div id="submenu-3" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-c3.php">C3 Charts</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-chartist.php">Chartist Charts</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-charts.php">Chart</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-morris.php">Morris</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-sparkline.php">Sparkline</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-gauge.php">Guage</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-4" aria-controls="submenu-4"><i
                                        class="fab fa-fw fa-wpforms"></i>Forms</a>
                                <div id="submenu-4" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="form-elements.php">Form Elements</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="form-validation.php">Parsely Validations</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="multiselect.php">Multiselect</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-5" aria-controls="submenu-5"><i
                                        class="fas fa-fw fa-table"></i>Tables</a>
                                <div id="submenu-5" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="general-table.php">General Tables</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="data-tables.php">Data Tables</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-divider">
                                Features
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-6" aria-controls="submenu-6"><i
                                        class="fas fa-fw fa-file"></i>Pages</a>
                                <div id="submenu-6" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="invoice.php">Invoice</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="blank-page.php">Blank Page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="blank-page-header.php">Blank Page Header</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="login.php">Login</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="404-page.php">404 page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="sign-up.php">Sign up Page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="forgot-password.php">Forgot Password</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="pricing.php">Pricing Tables</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="timeline.php">Timeline</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="calendar.php">Calendar</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="sortable-nestable-lists.php">Sortable/Nestable
                                                List</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="widgets.php">Widgets</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="media-object.php">Media Objects</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="cropper-image.php">Cropper</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="color-picker.php">Color Picker</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-7" aria-controls="submenu-7"><i
                                        class="fas fa-fw fa-inbox"></i>Apps <span
                                        class="badge badge-secondary">New</span></a>
                                <div id="submenu-7" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="inbox.php">Inbox</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="email-details.php">Email Detail</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="email-compose.php">Email Compose</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="message-chat.php">Message Chat</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-8" aria-controls="submenu-8"><i
                                        class="fas fa-fw fa-columns"></i>Icons</a>
                                <div id="submenu-8" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-fontawesome.php">FontAwesome Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-material.php">Material Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-simple-lineicon.php">Simpleline Icon</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-themify.php">Themify Icon</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-flag.php">Flag Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-weather.php">Weather Icon</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-9" aria-controls="submenu-9"><i
                                        class="fas fa-fw fa-map-marker-alt"></i>Maps</a>
                                <div id="submenu-9" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="map-google.php">Google Maps</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="map-vector.php">Vector Maps</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-10" aria-controls="submenu-10"><i
                                        class="fas fa-f fa-folder"></i>Menu Level</a>
                                <div id="submenu-10" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="#">Level 1</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                                data-target="#submenu-11" aria-controls="submenu-11">Level 2</a>
                                            <div id="submenu-11" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="#">Level 1</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="#">Level 2</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#">Level 3</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
    </div>
    <div class="dashboard-wrapper">
        <div class="container-fluid dashboard-content">
            <!-- ============================================================== -->
            <!-- pageheader  -->
            <!-- ============================================================== -->
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h2 class="pageheader-title">Themify Icons </h2>
                        <p class="pageheader-text">Proin placerat ante duiullam scelerisque a velit ac porta, fusce sit
                            amet vestibulum mi. Morbi lobortis pulvinar quam.</p>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Icons</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Themify Icons</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end wrapper  -->
            <!-- ============================================================== -->

            <div class="row">
                <!-- ============================================================== -->
                <!-- themify icon  -->
                <!-- ============================================================== -->
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <!-- ============================================================== -->
                    <!-- arrow icons  -->
                    <!-- ============================================================== -->
                    <div class="card">
                        <h5 class="card-header">Arrows & Direction Icons</h5>
                        <div class="card-body">
                            <div class="icon-list-demo row">
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrow-up"></i> ti-arrow-up
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrow-right"></i>
                                    ti-arrow-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrow-left"></i>
                                    ti-arrow-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrow-down"></i>
                                    ti-arrow-down </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrows-vertical"></i>
                                    ti-arrows-vertical </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrows-horizontal"></i>
                                    ti-arrows-horizontal </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-angle-up"></i> ti-angle-up
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-angle-right"></i>
                                    ti-angle-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-angle-left"></i>
                                    ti-angle-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-angle-down"></i>
                                    ti-angle-down </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-angle-double-up"></i>
                                    ti-angle-double-up </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-angle-double-right"></i>
                                    ti-angle-double-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-angle-double-left"></i>
                                    ti-angle-double-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-angle-double-down"></i>
                                    ti-angle-double-down </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-move"></i> ti-move </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-fullscreen"></i>
                                    ti-fullscreen </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrow-top-right"></i>
                                    ti-arrow-top-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrow-top-left"></i>
                                    ti-arrow-top-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrow-circle-up"></i>
                                    ti-arrow-circle-up </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrow-circle-right"></i>
                                    ti-arrow-circle-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrow-circle-left"></i>
                                    ti-arrow-circle-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrow-circle-down"></i>
                                    ti-arrow-circle-down </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-arrows-corner"></i>
                                    ti-arrows-corner </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-split-v"></i> ti-split-v
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-split-v-alt"></i>
                                    ti-split-v-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-split-h"></i> ti-split-h
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-hand-point-up"></i>
                                    ti-hand-point-up </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-hand-point-right"></i>
                                    ti-hand-point-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-hand-point-left"></i>
                                    ti-hand-point-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-hand-point-down"></i>
                                    ti-hand-point-down </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-back-right"></i>
                                    ti-back-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-back-left"></i>
                                    ti-back-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-exchange-vertical"></i>
                                    ti-exchange-vertical </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end arrow icons  -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- web app icons  -->
                    <!-- ============================================================== -->
                    <div class="card">
                        <h5 class="card-header">Web App Icons</h5>
                        <div class="card-body">
                            <div class="icon-list-demo row">
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-wand"></i> ti-wand </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-save"></i> ti-save </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-save-alt"></i> ti-save-alt
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-direction"></i>
                                    ti-direction </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-direction-alt"></i>
                                    ti-direction-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-user"></i> ti-user </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-link"></i> ti-link </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-unlink"></i> ti-unlink
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-trash"></i> ti-trash </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-target"></i> ti-target
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-tag"></i> ti-tag </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-desktop"></i> ti-desktop
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-tablet"></i> ti-tablet
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-mobile"></i> ti-mobile
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-email"></i> ti-email </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-star"></i> ti-star </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-spray"></i> ti-spray </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-signal"></i> ti-signal
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-shopping-cart"></i>
                                    ti-shopping-cart </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-shopping-cart-full"></i>
                                    ti-shopping-cart-full </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-settings"></i> ti-settings
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-search"></i> ti-search
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-zoom-in"></i> ti-zoom-in
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-zoom-out"></i> ti-zoom-out
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-cut"></i> ti-cut </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-ruler"></i> ti-ruler </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-ruler-alt-2"></i>
                                    ti-ruler-alt-2 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-ruler-pencil"></i>
                                    ti-ruler-pencil </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-ruler-alt"></i>
                                    ti-ruler-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-bookmark"></i> ti-bookmark
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-bookmark-alt"></i>
                                    ti-bookmark-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-reload"></i> ti-reload
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-plus"></i> ti-plus </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-minus"></i> ti-minus </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-close"></i> ti-close </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-pin"></i> ti-pin </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-pencil"></i> ti-pencil
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-pencil-alt"></i>
                                    ti-pencil-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-paint-roller"></i>
                                    ti-paint-roller </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-paint-bucket"></i>
                                    ti-paint-bucket </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-na"></i> ti-na </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-medall"></i> ti-medall
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-medall-alt"></i>
                                    ti-medall-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-marker"></i> ti-marker
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-marker-alt"></i>
                                    ti-marker-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-lock"></i> ti-lock </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-unlock"></i> ti-unlock
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-location-arrow"></i>
                                    ti-location-arrow </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout"></i> ti-layout
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layers"></i> ti-layers
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layers-alt"></i>
                                    ti-layers-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-key"></i> ti-key </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-image"></i> ti-image </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-heart"></i> ti-heart </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-heart-broken"></i>
                                    ti-heart-broken </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-hand-stop"></i>
                                    ti-hand-stop </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-hand-open"></i>
                                    ti-hand-open </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-hand-drag"></i>
                                    ti-hand-drag </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-flag"></i> ti-flag </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-flag-alt"></i> ti-flag-alt
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-flag-alt-2"></i>
                                    ti-flag-alt-2 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-eye"></i> ti-eye </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-import"></i> ti-import
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-export"></i> ti-export
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-cup"></i> ti-cup </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-crown"></i> ti-crown </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-comments"></i> ti-comments
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-comment"></i> ti-comment
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-comment-alt"></i>
                                    ti-comment-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-thought"></i> ti-thought
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-clip"></i> ti-clip </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-check"></i> ti-check </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-check-box"></i>
                                    ti-check-box </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-camera"></i> ti-camera
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-announcement"></i>
                                    ti-announcement </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-brush"></i> ti-brush </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-brush-alt"></i>
                                    ti-brush-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-palette"></i> ti-palette
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-briefcase"></i>
                                    ti-briefcase </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-bolt"></i> ti-bolt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-bolt-alt"></i> ti-bolt-alt
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-blackboard"></i>
                                    ti-blackboard </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-bag"></i> ti-bag </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-world"></i> ti-world </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-wheelchair"></i>
                                    ti-wheelchair </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-car"></i> ti-car </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-truck"></i> ti-truck </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-timer"></i> ti-timer </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-ticket"></i> ti-ticket
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-thumb-up"></i> ti-thumb-up
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-thumb-down"></i>
                                    ti-thumb-down </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-stats-up"></i> ti-stats-up
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-stats-down"></i>
                                    ti-stats-down </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-shine"></i> ti-shine </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-shift-right"></i>
                                    ti-shift-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-shift-left"></i>
                                    ti-shift-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-shift-right-alt"></i>
                                    ti-shift-right-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-shift-left-alt"></i>
                                    ti-shift-left-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-shield"></i> ti-shield
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-notepad"></i> ti-notepad
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-server"></i> ti-server
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-pulse"></i> ti-pulse </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-printer"></i> ti-printer
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-power-off"></i>
                                    ti-power-off </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-plug"></i> ti-plug </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-pie-chart"></i>
                                    ti-pie-chart </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-panel"></i> ti-panel </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-package"></i> ti-package
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-music"></i> ti-music </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-music-alt"></i>
                                    ti-music-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-mouse"></i> ti-mouse </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-mouse-alt"></i>
                                    ti-mouse-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-money"></i> ti-money </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-microphone"></i>
                                    ti-microphone </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-menu"></i> ti-menu </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-menu-alt"></i> ti-menu-alt
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-map"></i> ti-map </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-map-alt"></i> ti-map-alt
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-location-pin"></i>
                                    ti-location-pin </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-light-bulb"></i>
                                    ti-light-bulb </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-info"></i> ti-info </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-infinite"></i> ti-infinite
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-id-badge"></i> ti-id-badge
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-hummer"></i> ti-hummer
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-home"></i> ti-home </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-help"></i> ti-help </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-headphone"></i>
                                    ti-headphone </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-harddrives"></i>
                                    ti-harddrives </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-harddrive"></i>
                                    ti-harddrive </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-gift"></i> ti-gift </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-game"></i> ti-game </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-filter"></i> ti-filter
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-files"></i> ti-files </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-file"></i> ti-file </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-zip"></i> ti-zip </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-folder"></i> ti-folder
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-envelope"></i> ti-envelope
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-dashboard"></i>
                                    ti-dashboard </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-cloud"></i> ti-cloud </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-cloud-up"></i> ti-cloud-up
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-cloud-down"></i>
                                    ti-cloud-down </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-clipboard"></i>
                                    ti-clipboard </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-calendar"></i> ti-calendar
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-book"></i> ti-book </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-bell"></i> ti-bell </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-basketball"></i>
                                    ti-basketball </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-bar-chart"></i>
                                    ti-bar-chart </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-bar-chart-alt"></i>
                                    ti-bar-chart-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-archive"></i> ti-archive
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-anchor"></i> ti-anchor
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-alert"></i> ti-alert </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-alarm-clock"></i>
                                    ti-alarm-clock </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-agenda"></i> ti-agenda
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-write"></i> ti-write </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-wallet"></i> ti-wallet
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-video-clapper"></i>
                                    ti-video-clapper </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-video-camera"></i>
                                    ti-video-camera </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-vector"></i> ti-vector
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-support"></i> ti-support
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-stamp"></i> ti-stamp </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-slice"></i> ti-slice </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-shortcode"></i>
                                    ti-shortcode </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-receipt"></i> ti-receipt
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-pin2"></i> ti-pin2 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-pin-alt"></i> ti-pin-alt
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-pencil-alt2"></i>
                                    ti-pencil-alt2 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-eraser"></i> ti-eraser
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-more"></i> ti-more </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-more-alt"></i> ti-more-alt
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-microphone-alt"></i>
                                    ti-microphone-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-magnet"></i> ti-magnet
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-line-double"></i>
                                    ti-line-double </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-line-dotted"></i>
                                    ti-line-dotted </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-line-dashed"></i>
                                    ti-line-dashed </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-ink-pen"></i> ti-ink-pen
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-info-alt"></i> ti-info-alt
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-help-alt"></i> ti-help-alt
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-headphone-alt"></i>
                                    ti-headphone-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-gallery"></i> ti-gallery
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-face-smile"></i>
                                    ti-face-smile </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-face-sad"></i> ti-face-sad
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-credit-card"></i>
                                    ti-credit-card </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-comments-smiley"></i>
                                    ti-comments-smiley </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-time"></i> ti-time </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-share"></i> ti-share </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-share-alt"></i>
                                    ti-share-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-rocket"></i> ti-rocket
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-new-window"></i>
                                    ti-new-window </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-rss"></i> ti-rss </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-rss-alt"></i> ti-rss-alt
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end web app icons  -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- controls icon  -->
                    <!-- ============================================================== -->
                    <div class="card">
                        <h5 class="card-header">Control Icons</h5>
                        <div class="card-body">
                            <div class="icon-list-demo row">
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-control-stop"></i>
                                    ti-control-stop </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-control-shuffle"></i>
                                    ti-control-shuffle </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-control-play"></i>
                                    ti-control-play </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-control-pause"></i>
                                    ti-control-pause </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-control-forward"></i>
                                    ti-control-forward </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-control-backward"></i>
                                    ti-control-backward </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-volume"></i> ti-volume
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-control-skip-forward"></i>
                                    ti-control-skip-forward </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-control-skip-backward"></i>
                                    ti-control-skip-backward </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-control-record"></i>
                                    ti-control-record </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-control-eject"></i>
                                    ti-control-eject </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end controls icon  -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- text editor icons  -->
                    <!-- ============================================================== -->
                    <div class="card">
                        <h5 class="card-header">Text Editor Icons</h5>
                        <div class="card-body">
                            <div class="icon-list-demo row">
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-paragraph"></i>
                                    ti-paragraph </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-uppercase"></i>
                                    ti-uppercase </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-underline"></i>
                                    ti-underline </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-text"></i> ti-text </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-Italic"></i> ti-Italic
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-smallcap"></i> ti-smallcap
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-list"></i> ti-list </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-list-ol"></i> ti-list-ol
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-align-right"></i>
                                    ti-align-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-align-left"></i>
                                    ti-align-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-align-justify"></i>
                                    ti-align-justify </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-align-center"></i>
                                    ti-align-center </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-quote-right"></i>
                                    ti-quote-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-quote-left"></i>
                                    ti-quote-left </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- text editor icons  -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- layout icons  -->
                    <!-- ============================================================== -->
                    <div class="card">
                        <h5 class="card-header">Layout Icons</h5>
                        <div class="card-body">
                            <div class="icon-list-demo row">
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-width-full"></i>
                                    ti-layout-width-full </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-width-default"></i>
                                    ti-layout-width-default </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i
                                        class="ti-layout-width-default-alt"></i> ti-layout-width-default-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-tab"></i>
                                    ti-layout-tab </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-tab-window"></i>
                                    ti-layout-tab-window </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-tab-v"></i>
                                    ti-layout-tab-v </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-tab-min"></i>
                                    ti-layout-tab-min </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-slider"></i>
                                    ti-layout-slider </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-slider-alt"></i>
                                    ti-layout-slider-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-sidebar-right"></i>
                                    ti-layout-sidebar-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-sidebar-none"></i>
                                    ti-layout-sidebar-none </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-sidebar-left"></i>
                                    ti-layout-sidebar-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-placeholder"></i>
                                    ti-layout-placeholder </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-menu"></i>
                                    ti-layout-menu </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-menu-v"></i>
                                    ti-layout-menu-v </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-menu-separated"></i>
                                    ti-layout-menu-separated </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-menu-full"></i>
                                    ti-layout-menu-full </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-media-right"></i>
                                    ti-layout-media-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i
                                        class="ti-layout-media-right-alt"></i> ti-layout-media-right-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-media-overlay"></i>
                                    ti-layout-media-overlay </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i
                                        class="ti-layout-media-overlay-alt"></i> ti-layout-media-overlay-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i
                                        class="ti-layout-media-overlay-alt-2"></i> ti-layout-media-overlay-alt-2 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-media-left"></i>
                                    ti-layout-media-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-media-left-alt"></i>
                                    ti-layout-media-left-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-media-center"></i>
                                    ti-layout-media-center </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i
                                        class="ti-layout-media-center-alt"></i> ti-layout-media-center-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-list-thumb"></i>
                                    ti-layout-list-thumb </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-list-thumb-alt"></i>
                                    ti-layout-list-thumb-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-list-post"></i>
                                    ti-layout-list-post </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i
                                        class="ti-layout-list-large-image"></i> ti-layout-list-large-image </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-line-solid"></i>
                                    ti-layout-line-solid </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-grid4"></i>
                                    ti-layout-grid4 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-grid3"></i>
                                    ti-layout-grid3 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-grid2"></i>
                                    ti-layout-grid2 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-grid2-thumb"></i>
                                    ti-layout-grid2-thumb </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-cta-right"></i>
                                    ti-layout-cta-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-cta-left"></i>
                                    ti-layout-cta-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-cta-center"></i>
                                    ti-layout-cta-center </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-cta-btn-right"></i>
                                    ti-layout-cta-btn-right </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-cta-btn-left"></i>
                                    ti-layout-cta-btn-left </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-column4"></i>
                                    ti-layout-column4 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-column3"></i>
                                    ti-layout-column3 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-column2"></i>
                                    ti-layout-column2 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i
                                        class="ti-layout-accordion-separated"></i> ti-layout-accordion-separated </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i
                                        class="ti-layout-accordion-merged"></i> ti-layout-accordion-merged </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-accordion-list"></i>
                                    ti-layout-accordion-list </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-widgetized"></i>
                                    ti-widgetized </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-widget"></i> ti-widget
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-widget-alt"></i>
                                    ti-widget-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-view-list"></i>
                                    ti-view-list </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-view-list-alt"></i>
                                    ti-view-list-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-view-grid"></i>
                                    ti-view-grid </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-upload"></i> ti-upload
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-download"></i> ti-download
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-loop"></i> ti-loop </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-sidebar-2"></i>
                                    ti-layout-sidebar-2 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-grid4-alt"></i>
                                    ti-layout-grid4-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-grid3-alt"></i>
                                    ti-layout-grid3-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-grid2-alt"></i>
                                    ti-layout-grid2-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-column4-alt"></i>
                                    ti-layout-column4-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-column3-alt"></i>
                                    ti-layout-column3-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-layout-column2-alt"></i>
                                    ti-layout-column2-alt </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end layouts icon  -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- brand icon  -->
                    <!-- ============================================================== -->
                    <div class="card">
                        <h5 class="card-header">Brand Icons</h5>
                        <div class="card-body">
                            <div class="icon-list-demo row">
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-flickr"></i> ti-flickr
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-flickr-alt"></i>
                                    ti-flickr-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-instagram"></i>
                                    ti-instagram </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-google"></i> ti-google
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-github"></i> ti-github
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-facebook"></i> ti-facebook
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-dropbox"></i> ti-dropbox
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-dropbox-alt"></i>
                                    ti-dropbox-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-dribbble"></i> ti-dribbble
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-apple"></i> ti-apple </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-android"></i> ti-android
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-yahoo"></i> ti-yahoo </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-trello"></i> ti-trello
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-stack-overflow"></i>
                                    ti-stack-overflow </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-soundcloud"></i>
                                    ti-soundcloud </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-sharethis"></i>
                                    ti-sharethis </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-sharethis-alt"></i>
                                    ti-sharethis-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-reddit"></i> ti-reddit
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-microsoft"></i>
                                    ti-microsoft </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-microsoft-alt"></i>
                                    ti-microsoft-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-linux"></i> ti-linux </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-jsfiddle"></i> ti-jsfiddle
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-joomla"></i> ti-joomla
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-php5"></i> ti-php5 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-css3"></i> ti-css3 </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-drupal"></i> ti-drupal
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-wordpress"></i>
                                    ti-wordpress </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-tumblr"></i> ti-tumblr
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-tumblr-alt"></i>
                                    ti-tumblr-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-skype"></i> ti-skype </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-youtube"></i> ti-youtube
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-vimeo"></i> ti-vimeo </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-vimeo-alt"></i>
                                    ti-vimeo-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-twitter"></i> ti-twitter
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-twitter-alt"></i>
                                    ti-twitter-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-linkedin"></i> ti-linkedin
                                </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-pinterest"></i>
                                    ti-pinterest </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-pinterest-alt"></i>
                                    ti-pinterest-alt </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-themify-logo"></i>
                                    ti-themify-logo </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-themify-favicon"></i>
                                    ti-themify-favicon </div>
                                <div class="col-sm-6 col-md-4 col-lg-3 t-icon"> <i class="ti-themify-favicon-alt"></i>
                                    ti-themify-favicon-alt </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end brand icon  -->
                    <!-- ============================================================== -->
                </div>
                <!-- ============================================================== -->
                <!-- end themify icon  -->
                <!-- ============================================================== -->
            </div>

        </div>
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <div class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                        Copyright © 2018 Concept. All rights reserved. Dashboard by <a
                            href="https://colorlib.com/wp/">Colorlib</a>.
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                        <div class="text-md-right footer-links d-none d-sm-block">
                            <a href="javascript: void(0);">About</a>
                            <a href="javascript: void(0);">Support</a>
                            <a href="javascript: void(0);">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end footer -->
        <!-- ============================================================== -->
    </div>

    <!-- ============================================================== -->
    <!-- end main wrapper -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="../assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <script src="../assets/libs/js/main-js.js"></script>
</body>

</html>