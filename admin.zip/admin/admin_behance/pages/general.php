<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="../assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/libs/css/style.css">
    <link rel="stylesheet" href="../assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <title>Concept - Bootstrap 4 Admin Dashboard Template</title>
</head>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="../index.php">Concept</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <li class="nav-item">
                            <div id="custom-search" class="top-search-bar">
                                <input class="form-control" type="text" placeholder="Search..">
                            </div>
                        </li>
                        <li class="nav-item dropdown notification">
                            <a class="nav-link nav-icons" href="#" id="navbarDropdownMenuLink1" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false"><i class="fas fa-fw fa-bell"></i> <span
                                    class="indicator"></span></a>
                            <ul class="dropdown-menu dropdown-menu-right notification-dropdown">
                                <li>
                                    <div class="notification-title"> Notification</div>
                                    <div class="notification-list">
                                        <div class="list-group">
                                            <a href="#" class="list-group-item list-group-item-action active">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-2.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Jeremy
                                                            Rakestraw</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-3.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">John Abraham</span>is
                                                        now following you
                                                        <div class="notification-date">2 days ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-4.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Monaan Pechi</span> is
                                                        watching your main repository
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-5.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Jessica
                                                            Caruso</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="list-footer"> <a href="#">View all notifications</a></div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown connection">
                            <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false"> <i class="fas fa-fw fa-th"></i> </a>
                            <ul class="dropdown-menu dropdown-menu-right connection-dropdown">
                                <li class="connection-list">
                                    <div class="row">
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/github.png"
                                                    alt=""> <span>Github</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/dribbble.png"
                                                    alt=""> <span>Dribbble</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/dropbox.png"
                                                    alt=""> <span>Dropbox</span></a>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img
                                                    src="../assets/images/bitbucket.png" alt="">
                                                <span>Bitbucket</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img
                                                    src="../assets/images/mail_chimp.png" alt=""><span>Mail
                                                    chimp</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/slack.png"
                                                    alt=""> <span>Slack</span></a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="conntection-footer"><a href="#">More</a></div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img
                                    src="../assets/images/avatar-1.jpg" alt=""
                                    class="user-avatar-md rounded-circle"></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown"
                                aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info">
                                    <h5 class="mb-0 text-white nav-user-name">John Abraham</h5>
                                    <span class="status"></span><span class="ml-2">Available</span>
                                </div>
                                <a class="dropdown-item" href="#"><i class="fas fa-user mr-2"></i>Account</a>
                                <a class="dropdown-item" href="#"><i class="fas fa-cog mr-2"></i>Setting</a>
                                <a class="dropdown-item" href="#"><i class="fas fa-power-off mr-2"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link active" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-1" aria-controls="submenu-1"><i
                                        class="fa fa-fw fa-user-circle"></i>Dashboard <span
                                        class="badge badge-success">6</span></a>
                                <div id="submenu-1" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="index.php" data-toggle="collapse"
                                                aria-expanded="false" data-target="#submenu-1-2"
                                                aria-controls="submenu-1-2">E-Commerce</a>
                                            <div id="submenu-1-2" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../index.php">E Commerce Dashboard</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../ecommerce-product.php">Product
                                                            List</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../ecommerce-product-single.php">Product Single</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../ecommerce-product-checkout.php">Product
                                                            Checkout</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="../dashboard-finance.php">Finance</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="../dashboard-sales.php">Sales</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                                data-target="#submenu-1-1" aria-controls="submenu-1-1">Infulencer</a>
                                            <div id="submenu-1-1" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../dashboard-influencer.php">Influencer</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../influencer-finder.php">Influencer
                                                            Finder</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../influencer-profile.php">Influencer
                                                            Profile</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-2" aria-controls="submenu-2"><i
                                        class="fa fa-fw fa-rocket"></i>UI Elements</a>
                                <div id="submenu-2" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="cards.php">Cards <span
                                                    class="badge badge-secondary">New</span></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="general.php">General</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="carousel.php">Carousel</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="listgroup.php">List Group</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="typography.php">Typography</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="accordions.php">Accordions</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="tabs.php">Tabs</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-3" aria-controls="submenu-3"><i
                                        class="fas fa-fw fa-chart-pie"></i>Chart</a>
                                <div id="submenu-3" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-c3.php">C3 Charts</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-chartist.php">Chartist Charts</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-charts.php">Chart</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-morris.php">Morris</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-sparkline.php">Sparkline</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-gauge.php">Guage</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-4" aria-controls="submenu-4"><i
                                        class="fab fa-fw fa-wpforms"></i>Forms</a>
                                <div id="submenu-4" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="form-elements.php">Form Elements</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="form-validation.php">Parsely Validations</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="multiselect.php">Multiselect</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-5" aria-controls="submenu-5"><i
                                        class="fas fa-fw fa-table"></i>Tables</a>
                                <div id="submenu-5" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="general-table.php">General Tables</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="data-tables.php">Data Tables</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-divider">
                                Features
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-6" aria-controls="submenu-6"><i
                                        class="fas fa-fw fa-file"></i>Pages</a>
                                <div id="submenu-6" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="invoice.php">Invoice</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="blank-page.php">Blank Page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="blank-page-header.php">Blank Page Header</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="login.php">Login</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="404-page.php">404 page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="sign-up.php">Sign up Page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="forgot-password.php">Forgot Password</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="pricing.php">Pricing Tables</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="timeline.php">Timeline</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="calendar.php">Calendar</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="sortable-nestable-lists.php">Sortable/Nestable
                                                List</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="widgets.php">Widgets</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="media-object.php">Media Objects</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="cropper-image.php">Cropper</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="color-picker.php">Color Picker</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-7" aria-controls="submenu-7"><i
                                        class="fas fa-fw fa-inbox"></i>Apps <span
                                        class="badge badge-secondary">New</span></a>
                                <div id="submenu-7" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="inbox.php">Inbox</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="email-details.php">Email Detail</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="email-compose.php">Email Compose</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="message-chat.php">Message Chat</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-8" aria-controls="submenu-8"><i
                                        class="fas fa-fw fa-columns"></i>Icons</a>
                                <div id="submenu-8" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-fontawesome.php">FontAwesome Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-material.php">Material Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-simple-lineicon.php">Simpleline Icon</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-themify.php">Themify Icon</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-flag.php">Flag Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-weather.php">Weather Icon</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-9" aria-controls="submenu-9"><i
                                        class="fas fa-fw fa-map-marker-alt"></i>Maps</a>
                                <div id="submenu-9" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="map-google.php">Google Maps</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="map-vector.php">Vector Maps</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-10" aria-controls="submenu-10"><i
                                        class="fas fa-f fa-folder"></i>Menu Level</a>
                                <div id="submenu-10" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="#">Level 1</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                                data-target="#submenu-11" aria-controls="submenu-11">Level 2</a>
                                            <div id="submenu-11" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="#">Level 1</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="#">Level 2</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#">Level 3</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
            <div class="container-fluid dashboard-content">


                <div class="row">
                    <div class="col-xl-10">
                        <!-- ============================================================== -->
                        <!-- pageheader -->
                        <!-- ============================================================== -->
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="page-header" id="top">
                                    <h2 class="pageheader-title">General Elements</h2>
                                    <p class="pageheader-text">Proin placerat ante duiullam scelerisque a velit ac
                                        porta, fusce sit amet vestibulum mi. Morbi lobortis pulvinar quam.</p>
                                    <div class="page-breadcrumb">
                                        <nav aria-label="breadcrumb">
                                            <ol class="breadcrumb">
                                                <li class="breadcrumb-item"><a href="#"
                                                        class="breadcrumb-link">Dashboard</a></li>
                                                <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">UI
                                                        Elements</a></li>
                                                <li class="breadcrumb-item active" aria-current="page">General</li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end pageheader -->
                        <!-- ============================================================== -->
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <!-- ============================================================== -->
                                <!-- overview -->
                                <!-- ============================================================== -->
                                <div class="page-section" id="overview">
                                    <div class="row">
                                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                            <h2>Overview</h2>
                                            <p class="lead">Nam pulvinar interdum turpis a mattis. Etiam augue leo,
                                                mollis a massa sagittis, egestas pretium risus. Aliquam auctor nibh
                                                mauris, at fringilla elit lobortis sodales. Praesent volutpat felis et
                                                placerat elementum. </p>
                                            <ul class="list-unstyled arrow">
                                                <li> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                                                <li>Mauris bibendum massa ut porttitor congue.</li>
                                                <li>Morbi condimentum magna eget facilisis accumsan.</li>
                                                <li>Proin euismod eros nec libero efficitur, a dapibus mauris
                                                    condimentum. </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!-- ============================================================== -->
                                <!-- end overview -->
                                <!-- ============================================================== -->
                            </div>
                        </div>
                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- button  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="section-block" id="buttons">
                                    <h3 class="section-title">Buttons</h3>
                                    <p>Use custom button styles for actions in forms, dialogs, and more with support for
                                        multiple sizes, states, and more.</p>
                                </div>
                                <div class="card">
                                    <h5 class="card-header">Buttons</h5>
                                    <div class="card-body">
                                        <h4>Basic Buttons</h4>
                                        <a href="#" class="btn btn-primary">Primary</a>
                                        <a href="#" class="btn btn-brand">Brand</a>
                                        <a href="#" class="btn btn-secondary">Secondary</a>
                                        <a href="#" class="btn btn-success">Success</a>
                                        <a href="#" class="btn btn-danger">Danger</a>
                                        <a href="#" class="btn btn-warning">Warning</a>
                                        <a href="#" class="btn btn-info">Info</a>
                                        <a href="#" class="btn btn-light">Light</a>
                                        <a href="#" class="btn btn-dark">Dark</a>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Outline Buttons</h4>
                                        <a href="#" class="btn btn-outline-primary">Primary</a>
                                        <a href="#" class="btn btn-outline-brand">Brand</a>
                                        <a href="#" class="btn btn-outline-secondary">Secondary</a>
                                        <a href="#" class="btn btn-outline-success">Success</a>
                                        <a href="#" class="btn btn-outline-danger">Danger</a>
                                        <a href="#" class="btn btn-outline-warning">Warning</a>
                                        <a href="#" class="btn btn-outline-info">Info</a>
                                        <a href="#" class="btn btn-outline-light">Light</a>
                                        <a href="#" class="btn btn-outline-dark">Dark</a>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Rounded Buttons</h4>
                                        <a href="#" class="btn btn-rounded btn-primary">Primary</a>
                                        <a href="#" class="btn btn-rounded btn-brand">Brand</a>
                                        <a href="#" class="btn btn-rounded btn-secondary">Secondary</a>
                                        <a href="#" class="btn btn-rounded btn-success">Success</a>
                                        <a href="#" class="btn btn-rounded btn-danger">Danger</a>
                                        <a href="#" class="btn btn-rounded btn-warning">Warning</a>
                                        <a href="#" class="btn btn-rounded btn-info">Info</a>
                                        <a href="#" class="btn btn-rounded btn-light">Light</a>
                                        <a href="#" class="btn btn-rounded btn-dark">Dark</a>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Buttons Sizes</h4>
                                        <a href="#" class="btn btn-primary btn-lg">Large button</a>
                                        <a href="#" class="btn btn-primary">Default button</a>
                                        <a href="#" class="btn btn-primary btn-sm">Small button</a>
                                        <a href="#" class="btn btn-primary btn-xs">XSmall button</a>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Block Level Buttons</h4>
                                        <a href="#" class="btn btn-primary btn-block">Block level button</a>
                                        <a href="#" class="btn btn-brand btn-block">Block level button</a>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Active State</h4>
                                        <a href="#" class="btn btn-primary active">Primary</a>
                                        <a href="#" class="btn btn-brand active">Brand</a>
                                        <a href="#" class="btn btn-secondary active">Secondary</a>
                                        <a href="#" class="btn btn-success active">Success</a>
                                        <a href="#" class="btn btn-danger active">Danger</a>
                                        <a href="#" class="btn btn-warning active">Warning</a>
                                        <a href="#" class="btn btn-info active">Info</a>
                                        <a href="#" class="btn btn-light active">Light</a>
                                        <a href="#" class="btn btn-dark active">Dark</a>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Radio Buttons</h4>
                                        <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                            <label class="btn btn-primary active">
                                                <input type="radio" name="options" id="option1" checked>Active
                                            </label>
                                            <label class="btn btn-primary">
                                                <input type="radio" name="options" id="option2"> Radio
                                            </label>
                                            <label class="btn btn-primary">
                                                <input type="radio" name="options" id="option3"> Radio
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- end button  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- color  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="section-block" id="color">
                                    <h3 class="section-title">Color</h3>
                                    <p>Similar to the contextual text color classes, easily set the background of an
                                        element to any contextual class.</p>
                                </div>
                                <div class="card">
                                    <h5 class="card-header">Color</h5>
                                    <div class="card-body">
                                        <h4>Background Color</h4>
                                        <div class="p-3 mb-2 bg-primary text-white">.bg-primary</div>
                                        <div class="p-3 mb-2 bg-secondary text-white">.bg-secondary</div>
                                        <div class="p-3 mb-2 bg-success text-white">.bg-success</div>
                                        <div class="p-3 mb-2 bg-danger text-white">.bg-danger</div>
                                        <div class="p-3 mb-2 bg-warning text-dark">.bg-warning</div>
                                        <div class="p-3 mb-2 bg-info text-white">.bg-info</div>
                                        <div class="p-3 mb-2 bg-light text-dark">.bg-light</div>
                                        <div class="p-3 mb-2 bg-dark text-white">.bg-dark</div>
                                        <div class="p-3 mb-2 bg-white text-dark">.bg-white</div>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Color</h4>
                                        <p class="text-primary">.text-primary</p>
                                        <p class="text-secondary">.text-secondary</p>
                                        <p class="text-success">.text-success</p>
                                        <p class="text-danger">.text-danger</p>
                                        <p class="text-warning">.text-warning</p>
                                        <p class="text-info">.text-info</p>
                                        <p class="text-light bg-dark">.text-light</p>
                                        <p class="text-dark">.text-dark</p>
                                        <p class="text-muted">.text-muted</p>
                                        <p class="text-white bg-dark">.text-white</p>
                                    </div>
                                    <div class="card-body border-top border-boxes">
                                        <h4>Borders</h4>
                                        <span class="border"></span>
                                        <span class="border-top"></span>
                                        <span class="border-right"></span>
                                        <span class="border-bottom"></span>
                                        <span class="border-left"></span>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- end color  -->
                            <!-- ============================================================== -->
                        </div>
                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- alerts  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="section-block" id="alerts">
                                    <h3 class="section-title">Alerts</h3>
                                    <p>Provide contextual feedback messages for typical user actions with the handful of
                                        available and flexible alert messages.</p>
                                </div>
                                <div class="card">
                                    <h5 class="card-header">Alerts Examples</h5>
                                    <div class="card-body">
                                        <h4>Basic Alerts</h4>
                                        <div class="alert alert-primary" role="alert">
                                            This is a primary alert—check it out!
                                        </div>
                                        <div class="alert alert-secondary" role="alert">
                                            This is a secondary alert—check it out!
                                        </div>
                                        <div class="alert alert-success" role="alert">
                                            This is a success alert—check it out!
                                        </div>
                                        <div class="alert alert-danger" role="alert">
                                            This is a danger alert—check it out!
                                        </div>
                                        <div class="alert alert-warning" role="alert">
                                            This is a warning alert—check it out!
                                        </div>
                                        <div class="alert alert-info" role="alert">
                                            This is a info alert—check it out!
                                        </div>
                                        <div class="alert alert-light" role="alert">
                                            This is a light alert—check it out!
                                        </div>
                                        <div class="alert alert-dark" role="alert">
                                            This is a dark alert—check it out!
                                        </div>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Link Alerts</h4>
                                        <div class="alert alert-primary" role="alert">
                                            This is a primary alert—check it out!
                                        </div>
                                        <div class="alert alert-secondary" role="alert">
                                            This is a secondary alert—check it out!
                                        </div>
                                        <div class="alert alert-success" role="alert">
                                            This is a success alert—check it out!
                                        </div>
                                        <div class="alert alert-danger" role="alert">
                                            This is a danger alert—check it out!
                                        </div>
                                        <div class="alert alert-warning" role="alert">
                                            This is a warning alert—check it out!
                                        </div>
                                        <div class="alert alert-info" role="alert">
                                            This is a info alert—check it out!
                                        </div>
                                        <div class="alert alert-light" role="alert">
                                            This is a light alert—check it out!
                                        </div>
                                        <div class="alert alert-dark" role="alert">
                                            This is a dark alert—check it out!
                                        </div>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Additional Content</h4>
                                        <div class="alert alert-primary" role="alert">
                                            <h4 class="alert-heading">Well done!</h4>
                                            <p>Aww yeah, you successfully read this important alert message. This
                                                example text is going to run a bit longer so that you can see how
                                                spacing within an alert works with this kind of content.</p>
                                            <hr>
                                            <p class="mb-0">Whenever you need to, be sure to use margin utilities to
                                                keep things nice and tidy.</p>
                                        </div>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Dismissing</h4>
                                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                            <strong>Holy guacamole!</strong> You should check in on some of those fields
                                            below.
                                            <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- end alerts  -->
                            <!-- ============================================================== -->
                        </div>
                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- badges  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="section-block" id="badges">
                                    <h3 class="section-title">Badges</h3>
                                    <p>Use custom button styles for actions in forms, dialogs, and more with support for
                                        multiple sizes, states, and more.</p>
                                </div>
                                <div class="card">
                                    <h5 class="card-header">Badges Examples</h5>
                                    <div class="">
                                        <div class="card-body">
                                            <h4>Default Badges</h4>
                                            <span class="badge badge-primary">Primary</span>
                                            <span class="badge badge-brand">Brand</span>
                                            <span class="badge badge-secondary">Secondary</span>
                                            <span class="badge badge-success">Success</span>
                                            <span class="badge badge-danger">Danger</span>
                                            <span class="badge badge-warning">Warning</span>
                                            <span class="badge badge-info">Info</span>
                                            <span class="badge badge-light">Light</span>
                                            <span class="badge badge-dark">Dark</span>
                                        </div>
                                        <div class="card-body border-top">
                                            <h4>Contextual Variations</h4>
                                            <span class="badge badge-primary">Primary</span>
                                            <span class="badge badge-brand">Brand</span>
                                            <span class="badge badge-secondary">Secondary</span>
                                            <span class="badge badge-success">Success</span>
                                            <span class="badge badge-danger">Danger</span>
                                            <span class="badge badge-warning">Warning</span>
                                            <span class="badge badge-info">Info</span>
                                            <span class="badge badge-light">Light</span>
                                            <span class="badge badge-dark">Dark</span>
                                        </div>
                                        <div class="card-body border-top">
                                            <h4>Pill Badges</h4>
                                            <span class="badge badge-pill badge-primary">Primary</span>
                                            <span class="badge badge-pill badge-brand">Brand</span>
                                            <span class="badge badge-pill badge-secondary">Secondary</span>
                                            <span class="badge badge-pill badge-success">Success</span>
                                            <span class="badge badge-pill badge-danger">Danger</span>
                                            <span class="badge badge-pill badge-warning">Warning</span>
                                            <span class="badge badge-pill badge-info">Info</span>
                                            <span class="badge badge-pill badge-light">Light</span>
                                            <span class="badge badge-pill badge-dark">Dark</span>
                                        </div>
                                        <div class="card-body border-top">
                                            <h4>Link Badges</h4>
                                            <a href="#" class="badge badge-pill badge-primary">Primary</a>
                                            <a href="#" class="badge badge-pill badge-brand">Brand</a>
                                            <a href="#" class="badge badge-pill badge-secondary">Secondary</a>
                                            <a href="#" class="badge badge-pill badge-success">Success</a>
                                            <a href="#" class="badge badge-pill badge-danger">Danger</a>
                                            <a href="#" class="badge badge-pill badge-warning">Warning</a>
                                            <a href="#" class="badge badge-pill badge-info">Info</a>
                                            <a href="#" class="badge badge-pill badge-light">Light</a>
                                            <a href="#" class="badge badge-pill badge-dark">Dark</a>
                                        </div>
                                        <div class="card-body border-top">
                                            <h4>Dot Badges</h4>
                                            <span class="mr-2"> <span
                                                    class="badge-dot badge-primary"></span>Primary</span>
                                            <span class="mr-2"> <span class="badge-dot badge-brand"></span>Brand</span>
                                            <span class="mr-2"><span
                                                    class="badge-dot  badge-secondary"></span>Secondary</span>
                                            <span class="mr-2"><span
                                                    class="badge-dot badge-success"></span>Success</span>
                                            <span class="mr-2"><span class="badge-dot badge-danger"></span>Danger</span>
                                            <span class="mr-2"><span
                                                    class="badge-dot badge-warning"></span>Warning</span>
                                            <span class="mr-2"> <span class="badge-dot badge-info"></span>Info</span>
                                            <span class="mr-2"> <span class="badge-dot badge-light"></span>Light</span>
                                            <span class="mr-2"> <span class="badge-dot badge-dark"></span>Dark</span>
                                        </div>
                                        <div class="card-body border-top">
                                            <h4>Notification Badges</h4>
                                            <a href="#" class="btn btn-primary">
                                                Notifications <span class="badge badge-light">4</span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- end badges  -->
                            <!-- ============================================================== -->
                        </div>
                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- tooltip and popperover  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="section-block" id="tooltip">
                                    <h3 class="section-title">Tooltips & Popover</h3>
                                    <p>Use custom button styles for actions in forms, dialogs, and more with support for
                                        multiple sizes, states, and more.</p>
                                </div>
                                <div class="card">
                                    <h5 class="card-header">Tooltips & Popovers</h5>
                                    <div class="card-body">
                                        <h4>Tooltip</h4>
                                        <button type="button" class="btn btn-primary" data-toggle="tooltip"
                                            data-placement="top" title="Tooltip on top">
                                            Tooltip on top
                                        </button>
                                        <button type="button" class="btn btn-primary" data-toggle="tooltip"
                                            data-placement="right" title="Tooltip on right">
                                            Tooltip on right
                                        </button>
                                        <button type="button" class="btn btn-primary" data-toggle="tooltip"
                                            data-placement="bottom" title="Tooltip on bottom">
                                            Tooltip on bottom
                                        </button>
                                        <button type="button" class="btn btn-primary" data-toggle="tooltip"
                                            data-placement="left" title="Tooltip on left">
                                            Tooltip on left
                                        </button>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Popovers</h4>
                                        <button type="button" class="btn btn-lg btn-primary" data-toggle="popover"
                                            title="Popover title"
                                            data-content="And here's some amazing content. It's very engaging. Right?">Click
                                            to toggle popover</button>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Four Directions</h4>
                                        <button type="button" class="btn btn-primary" data-container="body"
                                            data-toggle="popover" data-placement="top"
                                            data-content="Vivamus sagittis lacus vel augue laoreet rutrum faucibus.">
                                            Popover on top
                                        </button>
                                        <button type="button" class="btn btn-primary" data-container="body"
                                            data-toggle="popover" data-placement="right"
                                            data-content="Vivamus sagittis lacus vel augue laoreet rutrum faucibus.">
                                            Popover on right
                                        </button>
                                        <button type="button" class="btn btn-primary" data-container="body"
                                            data-toggle="popover" data-placement="bottom"
                                            data-content="Vivamus sagittis lacus vel augue laoreet rutrum faucibus.">
                                            Popover on bottom
                                        </button>
                                        <button type="button" class="btn btn-primary" data-container="body"
                                            data-toggle="popover" data-placement="left"
                                            data-content="Vivamus sagittis lacus vel augue laoreet rutrum faucibus.">
                                            Popover on left
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- end tooltip and popperover  -->
                            <!-- ============================================================== -->
                        </div>
                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- modal  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="section-block" id="modal">
                                    <h3 class="section-title">Modals</h3>
                                    <p>Use Bootstrap’s JavaScript modal plugin to add dialogs to your site for
                                        lightboxes, user notifications, or completely custom content.</p>
                                </div>
                                <div class="card">
                                    <h5 class="card-header">Examples</h5>
                                    <div class="card-body">
                                        <div class="">
                                            <h4>Live Demo</h4>
                                            <!-- Button trigger modal -->
                                            <a href="#" class="btn btn-primary" data-toggle="modal"
                                                data-target="#exampleModal">
                                                Launch demo modal
                                            </a>
                                            <!-- Modal -->
                                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Modal title
                                                            </h5>
                                                            <a href="#" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </a>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Woohoo, You are readng this text in a modal! Use
                                                                Bootstrap’s JavaScript modal plugin to add dialogs to
                                                                your site for lightboxes, user notifications, or
                                                                completely custom content.</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <a href="#" class="btn btn-secondary"
                                                                data-dismiss="modal">Close</a>
                                                            <a href="#" class="btn btn-primary">Save changes</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- modal  -->
                            <!-- ============================================================== -->
                        </div>
                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- paginations  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="section-block" id="pagination">
                                    <h3 class="section-title">Paginations</h3>
                                    <p>Examples for showing pagination to indicate a series of related content exists
                                        across multiple pages.</p>
                                </div>
                                <div class="card">
                                    <h5 class="card-header">Pagination</h5>
                                    <div class="card-body">
                                        <h4>Default Pagination</h4>
                                        <nav aria-label="Page navigation example">
                                            <ul class="pagination">
                                                <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                                <li class="page-item"><a class="page-link" href="#">1</a></li>
                                                <li class="page-item active"><a class="page-link " href="#">2</a></li>
                                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                                <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Sizing</h4>
                                        <nav aria-label="...">
                                            <ul class="pagination pagination-lg">
                                                <li class="page-item">
                                                    <a class="page-link" href="#" tabindex="-1">1</a>
                                                </li>
                                                <li class="page-item active"><a class="page-link" href="#">2</a></li>
                                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                            </ul>
                                        </nav>
                                        <nav aria-label="...">
                                            <ul class="pagination pagination-sm">
                                                <li class="page-item">
                                                    <a class="page-link" href="#" tabindex="-1">1</a>
                                                </li>
                                                <li class="page-item active"><a class="page-link" href="#">2</a></li>
                                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                    <div class="card-body border-top">
                                        <h4>Working with icon</h4>
                                        <nav aria-label="Page navigation example">
                                            <ul class="pagination">
                                                <li class="page-item">
                                                    <a class="page-link" href="#" aria-label="Previous">
                                                        <span aria-hidden="true">&laquo;</span><span
                                                            class="sr-only">Previous</span> </a>
                                                </li>
                                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                                <li class="page-item">
                                                    <a class="page-link" href="#" aria-label="Next"><span
                                                            aria-hidden="true">&raquo;</span>
                                                        <span class="sr-only">Next</span></a>
                                                </li>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- pagination  -->
                            <!-- ============================================================== -->
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <!-- ============================================================== -->
                                <!-- images  -->
                                <!-- ============================================================== -->
                                <div class="card" id="images">
                                    <h5 class="card-header">Images</h5>
                                    <div class="card-body">
                                        <img src="http://via.placeholder.com/200x150" class="img-fluid mr-3"
                                            alt="Responsive image">
                                        <img src="http://via.placeholder.com/150x150" class="img-thumbnail mr-3"
                                            alt="Responsive image">
                                        <img src="http://via.placeholder.com/150x150" class="rounded-circle mr-3"
                                            alt="Responsive image">
                                    </div>
                                </div>
                                <!-- ============================================================== -->
                                <!-- end images -->
                                <!-- ============================================================== -->
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- progressbar  -->
                        <!-- ============================================================== -->
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="card" id="pro-bars">
                                    <h5 class="card-header">Progress Bars</h5>
                                    <div class="card-body">
                                        <div class="progress mb-3">
                                            <div class="progress-bar" role="progressbar" style="width: 25%"
                                                aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar" role="progressbar" style="width: 65%;"
                                                aria-valuenow="65" aria-valuemin="0" aria-valuemax="100">65%</div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar progress-bar-striped" role="progressbar"
                                                style="width: 10%" aria-valuenow="10" aria-valuemin="0"
                                                aria-valuemax="100"></div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar progress-bar-striped bg-success" role="progressbar"
                                                style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                                aria-valuemax="100"></div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar progress-bar-striped bg-info" role="progressbar"
                                                style="width: 50%" aria-valuenow="50" aria-valuemin="0"
                                                aria-valuemax="100"></div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar progress-bar-striped bg-warning" role="progressbar"
                                                style="width: 75%" aria-valuenow="75" aria-valuemin="0"
                                                aria-valuemax="100"></div>
                                        </div>
                                        <div class="progress mb-3">
                                            <div class="progress-bar progress-bar-striped bg-danger" role="progressbar"
                                                style="width: 100%" aria-valuenow="100" aria-valuemin="0"
                                                aria-valuemax="100"></div>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="75" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 75%"></div>
                                        </div>
                                    </div>
                                    <div class="card-body border-top">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <h5>Progress sm</h5>
                                                <div class="progress progress-sm">
                                                    <div class="progress-bar" role="progressbar" style="width: 35%"
                                                        aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <h5>Progress md</h5>
                                                <div class="progress progress-md">
                                                    <div class="progress-bar" role="progressbar" style="width: 35%"
                                                        aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <h5>Progress lg</h5>
                                                <div class="progress progress-lg">
                                                    <div class="progress-bar" role="progressbar" style="width: 35%"
                                                        aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <h5>Progress xl</h5>
                                                <div class="progress progress-xl">
                                                    <div class="progress-bar" role="progressbar" style="width: 35%"
                                                        aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end progressbar  -->
                        <!-- ============================================================== -->
                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- basic preloader  -->
                            <!-- ============================================================== -->
                            <div
                                class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card" id="loader">
                                    <h5 class="card-header">Basic Preloader</h5>
                                    <div class="card-body">
                                        <span class="dashboard-spinner spinner-xxl"></span>
                                        <span class="dashboard-spinner spinner-xl"></span>
                                        <span class="dashboard-spinner spinner-lg"></span>
                                        <span class="dashboard-spinner spinner-md"></span>
                                        <span class="dashboard-spinner spinner-sm"></span>
                                        <span class="dashboard-spinner spinner-xs"></span>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- end basic preloader  -->
                            <!-- ============================================================== -->
                            <div
                                class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 col-lg-6 col-md-6 col-sm-12 col-12">
                                <!-- ============================================================== -->
                                <!-- preloader states  -->
                                <!-- ============================================================== -->
                                <div class="card">
                                    <h5 class="card-header">Preloader States</h5>
                                    <div class="card-body">
                                        <span class="dashboard-spinner spinner-primary spinner-xxl"></span>
                                        <span class="dashboard-spinner spinner-success spinner-xl "></span>
                                        <span class="dashboard-spinner spinner-danger spinner-lg"></span>
                                        <span class="dashboard-spinner spinner-info spinner-md"></span>
                                        <span class="dashboard-spinner spinner-warning spinner-sm"></span>
                                        <span class="dashboard-spinner spinner-secondary spinner-xs"></span>
                                    </div>
                                </div>
                                <!-- ============================================================== -->
                                <!-- end preloader states  -->
                                <!-- ============================================================== -->
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- sidebar nav  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 col-12">
                        <div class="sidebar-nav-fixed">
                            <ul class="list-unstyled">
                                <li><a href="#overview" class="active">Overview</a></li>
                                <li><a href="#buttons">Buttons</a></li>
                                <li><a href="#color">Color</a></li>
                                <li><a href="#alerts">Alerts</a></li>
                                <li><a href="#badges">Badges</a></li>
                                <li><a href="#tooltip">Tooltip</a></li>
                                <li><a href="#modal">Modal</a></li>
                                <li><a href="#pagination">Paginations</a></li>
                                <li><a href="#images">Images</a></li>
                                <li><a href="#pro-bars">Progress Bars</a></li>
                                <li><a href="#loader">Loader</a></li>
                                <li><a href="#top">Back to Top</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end sidebar nav  -->
                    <!-- ============================================================== -->
                </div>


            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <div class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            Copyright © 2018 Concept. All rights reserved. Dashboard by <a
                                href="https://colorlib.com/wp/">Colorlib</a>.
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            <div class="text-md-right footer-links d-none d-sm-block">
                                <a href="javascript: void(0);">About</a>
                                <a href="javascript: void(0);">Support</a>
                                <a href="javascript: void(0);">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="../assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <script src="../assets/libs/js/main-js.js"></script>
</body>

</html>