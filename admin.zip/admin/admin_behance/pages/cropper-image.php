<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Concept - Bootstrap 4 Admin Dashboard Template</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="../assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/libs/css/style.css">
    <link rel="stylesheet" href="../assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendor/cropper/dist/cropper.min.css">
</head>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="../index.php">Concept</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <li class="nav-item">
                            <div id="custom-search" class="top-search-bar">
                                <input class="form-control" type="text" placeholder="Search..">
                            </div>
                        </li>
                        <li class="nav-item dropdown notification">
                            <a class="nav-link nav-icons" href="#" id="navbarDropdownMenuLink1" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false"><i class="fas fa-fw fa-bell"></i> <span
                                    class="indicator"></span></a>
                            <ul class="dropdown-menu dropdown-menu-right notification-dropdown">
                                <li>
                                    <div class="notification-title"> Notification</div>
                                    <div class="notification-list">
                                        <div class="list-group">
                                            <a href="#" class="list-group-item list-group-item-action active">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-2.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Jeremy
                                                            Rakestraw</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-3.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">
                                                            John Abraham</span>is now following you
                                                        <div class="notification-date">2 days ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-4.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Monaan Pechi</span> is
                                                        watching your main repository
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img
                                                            src="../assets/images/avatar-5.jpg" alt=""
                                                            class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span
                                                            class="notification-list-user-name">Jessica
                                                            Caruso</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="list-footer"> <a href="#">View all notifications</a></div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown connection">
                            <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false"> <i class="fas fa-fw fa-th"></i> </a>
                            <ul class="dropdown-menu dropdown-menu-right connection-dropdown">
                                <li class="connection-list">
                                    <div class="row">
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/github.png"
                                                    alt=""> <span>Github</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/dribbble.png"
                                                    alt=""> <span>Dribbble</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/dropbox.png"
                                                    alt=""> <span>Dropbox</span></a>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img
                                                    src="../assets/images/bitbucket.png" alt="">
                                                <span>Bitbucket</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img
                                                    src="../assets/images/mail_chimp.png" alt=""><span>Mail
                                                    chimp</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/slack.png"
                                                    alt=""> <span>Slack</span></a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="conntection-footer"><a href="#">More</a></div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img
                                    src="../assets/images/avatar-1.jpg" alt=""
                                    class="user-avatar-md rounded-circle"></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown"
                                aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info">
                                    <h5 class="mb-0 text-white nav-user-name">
                                        John Abraham</h5>
                                    <span class="status"></span><span class="ml-2">Available</span>
                                </div>
                                <a class="dropdown-item" href="#"><i class="fas fa-user mr-2"></i>Account</a>
                                <a class="dropdown-item" href="#"><i class="fas fa-cog mr-2"></i>Setting</a>
                                <a class="dropdown-item" href="#"><i class="fas fa-power-off mr-2"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link active" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-1" aria-controls="submenu-1"><i
                                        class="fa fa-fw fa-user-circle"></i>Dashboard <span
                                        class="badge badge-success">6</span></a>
                                <div id="submenu-1" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="index.php" data-toggle="collapse"
                                                aria-expanded="false" data-target="#submenu-1-2"
                                                aria-controls="submenu-1-2">E-Commerce</a>
                                            <div id="submenu-1-2" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../index.php">E Commerce Dashboard</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../ecommerce-product.php">Product
                                                            List</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../ecommerce-product-single.php">Product Single</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../ecommerce-product-checkout.php">Product
                                                            Checkout</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="../dashboard-finance.php">Finance</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="../dashboard-sales.php">Sales</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                                data-target="#submenu-1-1" aria-controls="submenu-1-1">Infulencer</a>
                                            <div id="submenu-1-1" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link"
                                                            href="../dashboard-influencer.php">Influencer</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../influencer-finder.php">Influencer
                                                            Finder</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="../influencer-profile.php">Influencer
                                                            Profile</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-2" aria-controls="submenu-2"><i
                                        class="fa fa-fw fa-rocket"></i>UI Elements</a>
                                <div id="submenu-2" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="cards.php">Cards <span
                                                    class="badge badge-secondary">New</span></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="general.php">General</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="carousel.php">Carousel</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="listgroup.php">List Group</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="typography.php">Typography</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="accordions.php">Accordions</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="tabs.php">Tabs</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-3" aria-controls="submenu-3"><i
                                        class="fas fa-fw fa-chart-pie"></i>Chart</a>
                                <div id="submenu-3" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-c3.php">C3 Charts</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-chartist.php">Chartist Charts</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-charts.php">Chart</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-morris.php">Morris</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-sparkline.php">Sparkline</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="chart-gauge.php">Guage</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-4" aria-controls="submenu-4"><i
                                        class="fab fa-fw fa-wpforms"></i>Forms</a>
                                <div id="submenu-4" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="form-elements.php">Form Elements</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="form-validation.php">Parsely Validations</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="multiselect.php">Multiselect</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-5" aria-controls="submenu-5"><i
                                        class="fas fa-fw fa-table"></i>Tables</a>
                                <div id="submenu-5" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="general-table.php">General Tables</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="data-tables.php">Data Tables</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-divider">
                                Features
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-6" aria-controls="submenu-6"><i
                                        class="fas fa-fw fa-file"></i>Pages</a>
                                <div id="submenu-6" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="invoice.php">Invoice</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="blank-page.php">Blank Page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="blank-page-header.php">Blank Page Header</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="login.php">Login</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="404-page.php">404 page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="sign-up.php">Sign up Page</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="forgot-password.php">Forgot Password</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="pricing.php">Pricing Tables</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="timeline.php">Timeline</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="calendar.php">Calendar</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="sortable-nestable-lists.php">Sortable/Nestable
                                                List</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="widgets.php">Widgets</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="media-object.php">Media Objects</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="cropper-image.php">Cropper</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="color-picker.php">Color Picker</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-7" aria-controls="submenu-7"><i
                                        class="fas fa-fw fa-inbox"></i>Apps <span
                                        class="badge badge-secondary">New</span></a>
                                <div id="submenu-7" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="inbox.php">Inbox</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="email-details.php">Email Detail</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="email-compose.php">Email Compose</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="message-chat.php">Message Chat</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-8" aria-controls="submenu-8"><i
                                        class="fas fa-fw fa-columns"></i>Icons</a>
                                <div id="submenu-8" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-fontawesome.php">FontAwesome Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-material.php">Material Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-simple-lineicon.php">Simpleline Icon</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-themify.php">Themify Icon</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-flag.php">Flag Icons</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="icon-weather.php">Weather Icon</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-9" aria-controls="submenu-9"><i
                                        class="fas fa-fw fa-map-marker-alt"></i>Maps</a>
                                <div id="submenu-9" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="map-google.php">Google Maps</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="map-vector.php">Vector Maps</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                    data-target="#submenu-10" aria-controls="submenu-10"><i
                                        class="fas fa-f fa-folder"></i>Menu Level</a>
                                <div id="submenu-10" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="#">Level 1</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false"
                                                data-target="#submenu-11" aria-controls="submenu-11">Level 2</a>
                                            <div id="submenu-11" class="collapse submenu" style="">
                                                <ul class="nav flex-column">
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="#">Level 1</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="#">Level 2</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#">Level 3</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
            <div class="container-fluid dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Cropper</h2>
                            <p class="pageheader-text">Proin placerat ante duiullam scelerisque a velit ac porta, fusce
                                sit amet vestibulum mi. Morbi lobortis pulvinar quam.</p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Pages</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Cropper</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <!-- ============================================================== -->
                    <!-- cropper  -->
                    <!-- ============================================================== -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-9">
                                        <!-- <h3>Demo:</h3> -->
                                        <div class="img-container">
                                            <img id="image" src="../assets/images/card-img-1.jpg" alt="Picture">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <!-- <h3>Preview:</h3> -->
                                        <div class="docs-preview clearfix">
                                            <div class="img-preview preview-lg"></div>
                                            <div class="img-preview preview-md"></div>
                                            <div class="img-preview preview-sm"></div>
                                            <div class="img-preview preview-xs"></div>
                                        </div>
                                        <!-- <h3>Data:</h3> -->
                                        <div class="docs-data">
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-prepend">
                                                    <label class="input-group-text" for="dataX">X</label>
                                                </span>
                                                <input type="text" class="form-control" id="dataX" placeholder="x">
                                                <span class="input-group-append">
                                                    <span class="input-group-text">px</span>
                                                </span>
                                            </div>
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-prepend">
                                                    <label class="input-group-text" for="dataY">Y</label>
                                                </span>
                                                <input type="text" class="form-control" id="dataY" placeholder="y">
                                                <span class="input-group-append">
                                                    <span class="input-group-text">px</span>
                                                </span>
                                            </div>
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-prepend">
                                                    <label class="input-group-text" for="dataWidth">Width</label>
                                                </span>
                                                <input type="text" class="form-control" id="dataWidth"
                                                    placeholder="width">
                                                <span class="input-group-append">
                                                    <span class="input-group-text">px</span>
                                                </span>
                                            </div>
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-prepend">
                                                    <label class="input-group-text" for="dataHeight">Height</label>
                                                </span>
                                                <input type="text" class="form-control" id="dataHeight"
                                                    placeholder="height">
                                                <span class="input-group-append">
                                                    <span class="input-group-text">px</span>
                                                </span>
                                            </div>
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-prepend">
                                                    <label class="input-group-text" for="dataRotate">Rotate</label>
                                                </span>
                                                <input type="text" class="form-control" id="dataRotate"
                                                    placeholder="rotate">
                                                <span class="input-group-append">
                                                    <span class="input-group-text">deg</span>
                                                </span>
                                            </div>
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-prepend">
                                                    <label class="input-group-text" for="dataScaleX">ScaleX</label>
                                                </span>
                                                <input type="text" class="form-control" id="dataScaleX"
                                                    placeholder="scaleX">
                                            </div>
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-prepend">
                                                    <label class="input-group-text" for="dataScaleY">ScaleY</label>
                                                </span>
                                                <input type="text" class="form-control" id="dataScaleY"
                                                    placeholder="scaleY">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-9 docs-buttons">
                        <!-- <h3>Toolbar:</h3> -->
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-light" data-method="setDragMode"
                                data-option="move" title="Move">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;setDragMode&quot;, &quot;move&quot;)">
                                    <span class="fas fa-arrows-alt"></span>
                                </span>
                            </button>
                            <button type="button" class="btn btn-outline-light" data-method="setDragMode"
                                data-option="crop" title="Crop">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;setDragMode&quot;, &quot;crop&quot;)">
                                    <span class="fa fa-crop"></span>
                                </span>
                            </button>
                        </div>
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-light" data-method="zoom" data-option="0.1"
                                title="Zoom In">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;zoom&quot;, 0.1)">
                                    <span class="fa fa-search-plus"></span>
                                </span>
                            </button>
                            <button type="button" class="btn btn-outline-light" data-method="zoom" data-option="-0.1"
                                title="Zoom Out">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;zoom&quot;, -0.1)">
                                    <span class="fa fa-search-minus"></span>
                                </span>
                            </button>
                        </div>
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-light" data-method="move" data-option="-10"
                                data-second-option="0" title="Move Left">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;move&quot;, -10, 0)">
                                    <span class="fa fa-arrow-left"></span>
                                </span>
                            </button>
                            <button type="button" class="btn btn-outline-light" data-method="move" data-option="10"
                                data-second-option="0" title="Move Right">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;move&quot;, 10, 0)">
                                    <span class="fa fa-arrow-right"></span>
                                </span>
                            </button>
                            <button type="button" class="btn btn-outline-light" data-method="move" data-option="0"
                                data-second-option="-10" title="Move Up">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;move&quot;, 0, -10)">
                                    <span class="fa fa-arrow-up"></span>
                                </span>
                            </button>
                            <button type="button" class="btn btn-outline-light" data-method="move" data-option="0"
                                data-second-option="10" title="Move Down">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;move&quot;, 0, 10)">
                                    <span class="fa fa-arrow-down"></span>
                                </span>
                            </button>
                        </div>
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-light" data-method="rotate" data-option="-45"
                                title="Rotate Left">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;rotate&quot;, -45)">
                                    <span class="fas fa-undo"></span>
                                </span>
                            </button>
                            <button type="button" class="btn btn-outline-light" data-method="rotate" data-option="45"
                                title="Rotate Right">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;rotate&quot;, 45)">
                                    <span class="fa fa-redo"></span>
                                </span>
                            </button>
                        </div>
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-light" data-method="scaleX" data-option="-1"
                                title="Flip Horizontal">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;scaleX&quot;, -1)">
                                    <span class="fa fa-arrows-alt-h"></span>
                                </span>
                            </button>
                            <button type="button" class="btn btn-outline-light" data-method="scaleY" data-option="-1"
                                title="Flip Vertical">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;scaleY&quot;, -1)">
                                    <span class="fa fa-arrows-alt-v"></span>
                                </span>
                            </button>
                        </div>
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-light" data-method="crop" title="Crop">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;crop&quot;)">
                                    <span class="fa fa-check"></span>
                                </span>
                            </button>
                            <button type="button" class="btn btn-outline-light" data-method="clear" title="Clear">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;clear&quot;)">
                                    <span class="fas fa-trash"></span>
                                </span>
                            </button>
                        </div>
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-light" data-method="disable" title="Disable">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;disable&quot;)">
                                    <span class="fa fa-lock"></span>
                                </span>
                            </button>
                            <button type="button" class="btn btn-outline-light" data-method="enable" title="Enable">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;enable&quot;)">
                                    <span class="fa fa-unlock"></span>
                                </span>
                            </button>
                        </div>
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-light" data-method="reset" title="Reset">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;reset&quot;)">
                                    <span class="fas fa-undo-alt"></span>
                                </span>
                            </button>
                            <label class="btn btn-outline-light btn-upload m-b-0" for="inputImage"
                                title="Upload image file">
                                <input type="file" class="sr-only" id="inputImage" name="file"
                                    accept=".jpg,.jpeg,.png,.gif,.bmp,.tiff">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="Import image with Blob URLs">
                                    <span class="fa fa-upload"></span>
                                </span>
                            </label>
                            <button type="button" class="btn btn-outline-light" data-method="destroy" title="Destroy">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;destroy&quot;)">
                                    <span class="fa fa-power-off"></span>
                                </span>
                            </button>
                        </div>
                        <div class="btn-group btn-group-crop">
                            <button type="button" class="btn btn-outline-light" data-method="getCroppedCanvas"
                                data-option="{ &quot;maxWidth&quot;: 4096, &quot;maxHeight&quot;: 4096 }">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;getCroppedCanvas&quot;, { maxWidth: 4096, maxHeight: 4096 })">
                                    Get Cropped Canvas
                                </span>
                            </button>
                            <button type="button" class="btn btn-outline-light" data-method="getCroppedCanvas"
                                data-option="{ &quot;width&quot;: 160, &quot;height&quot;: 90 }">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;getCroppedCanvas&quot;, { width: 160, height: 90 })">
                                    160&times;90
                                </span>
                            </button>
                            <button type="button" class="btn btn-outline-light" data-method="getCroppedCanvas"
                                data-option="{ &quot;width&quot;: 320, &quot;height&quot;: 180 }">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="$().cropper(&quot;getCroppedCanvas&quot;, { width: 320, height: 180 })">
                                    320&times;180
                                </span>
                            </button>
                        </div>
                        <!-- Show the cropped image in modal -->
                        <div class="modal fade docs-cropped" id="getCroppedCanvasModal" aria-hidden="true"
                            aria-labelledby="getCroppedCanvasTitle" role="dialog" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="getCroppedCanvasTitle">Cropped</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body"></div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-light"
                                            data-dismiss="modal">Close</button>
                                        <a class="btn btn-outline-light" id="download" href="javascript:void(0);"
                                            download="cropped.php">Download</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.modal -->
                        <button type="button" class="btn btn-outline-light" data-method="getData" data-option
                            data-target="#putData">
                            <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                title="$().cropper(&quot;getData&quot;)">
                                Get Data
                            </span>
                        </button>
                        <button type="button" class="btn btn-outline-light" data-method="setData"
                            data-target="#putData">
                            <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                title="$().cropper(&quot;setData&quot;, data)">
                                Set Data
                            </span>
                        </button>
                        <button type="button" class="btn btn-outline-light" data-method="getContainerData" data-option
                            data-target="#putData">
                            <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                title="$().cropper(&quot;getContainerData&quot;)">
                                Get Container Data
                            </span>
                        </button>
                        <button type="button" class="btn btn-outline-light" data-method="getImageData" data-option
                            data-target="#putData">
                            <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                title="$().cropper(&quot;getImageData&quot;)">
                                Get Image Data
                            </span>
                        </button>
                        <button type="button" class="btn btn-outline-light" data-method="getCanvasData" data-option
                            data-target="#putData">
                            <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                title="$().cropper(&quot;getCanvasData&quot;)">
                                Get Canvas Data
                            </span>
                        </button>
                        <button type="button" class="btn btn-outline-light" data-method="setCanvasData"
                            data-target="#putData">
                            <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                title="$().cropper(&quot;setCanvasData&quot;, data)">
                                Set Canvas Data
                            </span>
                        </button>
                        <button type="button" class="btn btn-outline-light" data-method="getCropBoxData" data-option
                            data-target="#putData">
                            <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                title="$().cropper(&quot;getCropBoxData&quot;)">
                                Get Crop Box Data
                            </span>
                        </button>
                        <button type="button" class="btn btn-outline-light" data-method="setCropBoxData"
                            data-target="#putData">
                            <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                title="$().cropper(&quot;setCropBoxData&quot;, data)">
                                Set Crop Box Data
                            </span>
                        </button>
                        <button type="button" class="btn btn-outline-light" data-method="moveTo" data-option="0">
                            <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                title="cropper.moveTo(0)">
                                Move to [0,0]
                            </span>
                        </button>
                        <button type="button" class="btn btn-outline-light" data-method="zoomTo" data-option="1">
                            <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                title="cropper.zoomTo(1)">
                                Zoom to 100%
                            </span>
                        </button>
                        <button type="button" class="btn btn-outline-light" data-method="rotateTo" data-option="180">
                            <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                title="cropper.rotateTo(180)">
                                Rotate 180°
                            </span>
                        </button>
                        <button type="button" class="btn btn-outline-light" data-method="scale" data-option="-2"
                            data-second-option="-1">
                            <span class="docs-tooltip" data-toggle="tooltip" title="cropper.scale(-2, -1)">
                                Scale (-2, -1)
                            </span>
                        </button>
                        <textarea class="form-control" id="putData" rows="1"
                            placeholder="Get data to here or set data with this value"></textarea>
                    </div>
                    <!-- /.docs-buttons -->
                    <div class="col-md-3 docs-toggles">
                        <!-- <h3>Toggles:</h3> -->
                        <div class="btn-group d-flex flex-nowrap" data-toggle="buttons">
                            <label class="btn btn-outline-light active">
                                <input type="radio" class="sr-only" id="aspectRatio0" name="aspectRatio"
                                    value="1.7777777777777777">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="aspectRatio: 16 / 9">
                                    16:9
                                </span>
                            </label>
                            <label class="btn btn-outline-light">
                                <input type="radio" class="sr-only" id="aspectRatio1" name="aspectRatio"
                                    value="1.3333333333333333">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="aspectRatio: 4 / 3">
                                    4:3
                                </span>
                            </label>
                            <label class="btn btn-outline-light">
                                <input type="radio" class="sr-only" id="aspectRatio2" name="aspectRatio" value="1">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="aspectRatio: 1 / 1">
                                    1:1
                                </span>
                            </label>
                            <label class="btn btn-outline-light">
                                <input type="radio" class="sr-only" id="aspectRatio3" name="aspectRatio"
                                    value="0.6666666666666666">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="aspectRatio: 2 / 3">
                                    2:3
                                </span>
                            </label>
                            <label class="btn btn-outline-light">
                                <input type="radio" class="sr-only" id="aspectRatio4" name="aspectRatio" value="NaN">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="aspectRatio: NaN">
                                    Free
                                </span>
                            </label>
                        </div>
                        <div class="btn-group d-flex flex-nowrap" data-toggle="buttons">
                            <label class="btn btn-outline-light active">
                                <input type="radio" class="sr-only" id="viewMode0" name="viewMode" value="0" checked>
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="View Mode 0">
                                    VM0
                                </span>
                            </label>
                            <label class="btn btn-outline-light">
                                <input type="radio" class="sr-only" id="viewMode1" name="viewMode" value="1">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="View Mode 1">
                                    VM1
                                </span>
                            </label>
                            <label class="btn btn-outline-light">
                                <input type="radio" class="sr-only" id="viewMode2" name="viewMode" value="2">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="View Mode 2">
                                    VM2
                                </span>
                            </label>
                            <label class="btn btn-outline-light">
                                <input type="radio" class="sr-only" id="viewMode3" name="viewMode" value="3">
                                <span class="docs-tooltip" data-toggle="tooltip" data-animation="false"
                                    title="View Mode 3">
                                    VM3
                                </span>
                            </label>
                        </div>
                        <div class="dropdown dropup docs-options">
                            <button type="button" class="btn btn-outline-light btn-block dropdown-toggle"
                                id="toggleOptions" data-toggle="dropdown" aria-expanded="true">
                                Toggle Options
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="toggleOptions" role="menu">
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="responsive" type="checkbox"
                                            name="responsive" checked>
                                        <label class="form-check-label" for="responsive">responsive</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="restore" type="checkbox" name="restore"
                                            checked>
                                        <label class="form-check-label" for="restore">restore</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="checkCrossOrigin" type="checkbox"
                                            name="checkCrossOrigin" checked>
                                        <label class="form-check-label" for="checkCrossOrigin">checkCrossOrigin</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="checkOrientation" type="checkbox"
                                            name="checkOrientation" checked>
                                        <label class="form-check-label" for="checkOrientation">checkOrientation</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="modal" type="checkbox" name="modal" checked>
                                        <label class="form-check-label" for="modal">modal</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="guides" type="checkbox" name="guides"
                                            checked>
                                        <label class="form-check-label" for="guides">guides</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="center" type="checkbox" name="center"
                                            checked>
                                        <label class="form-check-label" for="center">center</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="highlight" type="checkbox" name="highlight"
                                            checked>
                                        <label class="form-check-label" for="highlight">highlight</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="background" type="checkbox"
                                            name="background" checked>
                                        <label class="form-check-label" for="background">background</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="autoCrop" type="checkbox" name="autoCrop"
                                            checked>
                                        <label class="form-check-label" for="autoCrop">autoCrop</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="movable" type="checkbox" name="movable"
                                            checked>
                                        <label class="form-check-label" for="movable">movable</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="rotatable" type="checkbox" name="rotatable"
                                            checked>
                                        <label class="form-check-label" for="rotatable">rotatable</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="scalable" type="checkbox" name="scalable"
                                            checked>
                                        <label class="form-check-label" for="scalable">scalable</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="zoomable" type="checkbox" name="zoomable"
                                            checked>
                                        <label class="form-check-label" for="zoomable">zoomable</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="zoomOnTouch" type="checkbox"
                                            name="zoomOnTouch" checked>
                                        <label class="form-check-label" for="zoomOnTouch">zoomOnTouch</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="zoomOnWheel" type="checkbox"
                                            name="zoomOnWheel" checked>
                                        <label class="form-check-label" for="zoomOnWheel">zoomOnWheel</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="cropBoxMovable" type="checkbox"
                                            name="cropBoxMovable" checked>
                                        <label class="form-check-label" for="cropBoxMovable">cropBoxMovable</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="cropBoxResizable" type="checkbox"
                                            name="cropBoxResizable" checked>
                                        <label class="form-check-label" for="cropBoxResizable">cropBoxResizable</label>
                                    </div>
                                </li>
                                <li class="dropdown-item">
                                    <div class="form-check">
                                        <input class="form-check-input" id="toggleDragModeOnDblclick" type="checkbox"
                                            name="toggleDragModeOnDblclick" checked>
                                        <label class="form-check-label"
                                            for="toggleDragModeOnDblclick">toggleDragModeOnDblclick</label>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <!-- /.dropdown -->
                    </div>
                    <!-- /.docs-toggles -->
                </div>
                <!-- ============================================================== -->
                <!-- end cropper  -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <div class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            Copyright © 2018 Concept. All rights reserved. Dashboard by <a
                                href="https://colorlib.com/wp/">Colorlib</a>.
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            <div class="text-md-right footer-links d-none d-sm-block">
                                <a href="javascript: void(0);">About</a>
                                <a href="javascript: void(0);">Support</a>
                                <a href="javascript: void(0);">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="../assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <script src="../assets/libs/js/main-js.js"></script>
    <script src="../assets/vendor/cropper/dist/cropper.min.js"></script>
    <script src="../assets/vendor/cropper/dist/cropper-int.js"></script>
</body>


</html>